import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import {
  BookOpen,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Flame,
  Printer,
  RotateCcw,
  TriangleAlert,
} from "lucide-react";
import {
  DATESHEET,
  PLAN_START,
  SOURCES,
  SUBJECTS,
  defaultSubjectIds,
  subjectsFromIds,
  type StreamId,
  type Subject,
} from "@/data/syllabus";
import {
  addDays,
  backToBack,
  daysBetween,
  formatDay,
  formatFull,
  generatePlan,
  isoFromDate,
  parseISODate,
  type DayPlan,
  type PlanBlock,
} from "@/data/plan";
import { useDesk, type ChapterProgress, type ChapterStatus, type MockScore } from "@/data/store";

const STREAMS: { id: StreamId; label: string; line: string }[] = [
  { id: "commerce", label: "Commerce", line: "Accountancy, Business Studies, Economics, English, Painting" },
  { id: "science", label: "Science", line: "Physics, Chemistry, Maths, English" },
  { id: "humanities", label: "Humanities", line: "History, Political Science, Geography, Economics, English" },
];

const STATUS_LABEL: Record<ChapterStatus, string> = {
  not_started: "Not started",
  learning: "Learning",
  revised: "Revised",
};

function useHydrated(): boolean {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const unsub = useDesk.persist.onFinishHydration(() => setReady(true));
    void useDesk.persist.rehydrate();
    if (useDesk.persist.hasHydrated()) setReady(true);
    return unsub;
  }, []);
  return ready;
}

function useNow(): Date | null {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = window.setInterval(tick, 30000);
    return () => window.clearInterval(id);
  }, []);
  return now;
}

export function DeskApp() {
  const hydrated = useHydrated();
  const confirmed = useDesk((s) => s.confirmed);
  if (!hydrated || !confirmed) return <ConfirmScreen />;
  return <Dashboard />;
}

function clashes(ids: string[]): string[] {
  const subjects = subjectsFromIds(ids);
  const groups = new Map<string, string[]>();
  for (const subject of subjects) {
    const list = groups.get(subject.examDate) ?? [];
    list.push(subject.name);
    groups.set(subject.examDate, list);
  }
  return [...groups.values()].filter((names) => names.length > 1).map((names) => names.join(" and "));
}

function ConfirmScreen() {
  const storedStream = useDesk((s) => s.stream);
  const storedIds = useDesk((s) => s.subjectIds);
  const confirm = useDesk((s) => s.confirm);
  const [stream, setStream] = useState<StreamId>(storedStream);
  const [ids, setIds] = useState<string[]>(storedIds.length ? storedIds : defaultSubjectIds(storedStream));

  const selected = subjectsFromIds(ids);
  const problems = clashes(ids);
  const core = SUBJECTS.filter((s) => s.streams.includes(stream));
  const extra = SUBJECTS.filter((s) => !s.streams.includes(stream));

  function chooseStream(next: StreamId) {
    setStream(next);
    setIds(defaultSubjectIds(next));
  }

  function toggle(id: string) {
    setIds((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-8 pb-16">
      <p className="text-sm font-medium tracking-wide text-muted uppercase">CBSE Class 12 · session 2026-27</p>
      <h1 className="mt-2 font-serif text-4xl text-fg">Confirm your subjects</h1>
      <p className="mt-3 text-muted">
        The plan is built only after this step. Commerce is selected, with Painting ticked, because that is the set you named.
        Change anything that is wrong.
      </p>

      <section className="mt-6 rounded-2xl border border-border bg-surface p-4">
        <p className="text-sm font-medium text-fg">Datesheet status: final</p>
        <p className="mt-2 text-sm text-muted">{DATESHEET.note}</p>
        <p className="mt-2 text-sm text-muted">
          Window: {DATESHEET.window}. Circular {DATESHEET.circular}, released {DATESHEET.released}. Every paper starts at {DATESHEET.startTime}.
        </p>
      </section>

      <fieldset className="mt-6">
        <legend className="text-sm font-medium text-fg">Stream</legend>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {STREAMS.map((item) => {
            const on = stream === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-pressed={on}
                onClick={() => chooseStream(item.id)}
                className={`min-h-11 rounded-2xl border px-3 py-3 text-left ${on ? "border-fg bg-surface-2" : "border-border bg-surface"}`}
              >
                <span className="block font-medium text-fg">{item.label}</span>
                <span className="mt-1 block text-xs text-muted">{item.line}</span>
              </button>
            );
          })}
        </div>
      </fieldset>

      <SubjectGroup title="In this stream" subjects={core} ids={ids} onToggle={toggle} />
      <SubjectGroup title="Other papers you might sit" subjects={extra} ids={ids} onToggle={toggle} />

      {stream === "commerce" && (
        <p className="mt-3 text-sm text-muted">
          Painting is on because you asked for it. Untick it if you do not sit code 049. It is the day after Accountancy, so the plan finishes Painting before 23 February.
        </p>
      )}

      {problems.length > 0 && (
        <p className="mt-4 flex gap-2 rounded-2xl border border-border bg-surface p-3 text-sm text-fg">
          <TriangleAlert className="mt-0.5 size-4 shrink-0 text-paint" aria-hidden="true" />
          Same morning, pick one: {problems.join("; ")}.
        </p>
      )}

      <section className="mt-6">
        <h2 className="font-serif text-2xl text-fg">Your papers, in order</h2>
        {selected.length === 0 ? (
          <p className="mt-2 text-sm text-muted">Tick at least one subject.</p>
        ) : (
          <ul className="mt-3 flex flex-col gap-2">
            {selected.map((subject) => (
              <li key={subject.id} className="rounded-2xl border border-border bg-surface px-3 py-3" style={{ boxShadow: `inset 3px 0 0 var(--color-${subject.token})` }}>
                <p className="font-medium text-fg">
                  {formatFull(subject.examDate)} · {subject.name}
                </p>
                <p className="text-sm text-muted">
                  Code {subject.code} · 10:30 am to {subject.end === "12:30" ? "12:30 pm" : "1:30 pm"} · {subject.marks}
                </p>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="mt-6">
        <h2 className="font-serif text-2xl text-fg">Chapters in the plan</h2>
        <p className="mt-2 text-sm text-muted">
          These follow the 2026-27 course, not a ten-year-old guide. Lines under a subject are left out on purpose.
        </p>
        <div className="mt-3 flex flex-col gap-2">
          {selected.map((subject) => (
            <details key={subject.id} className="rounded-2xl border border-border bg-surface px-3 py-2">
              <summary className="min-h-11 cursor-pointer py-2 font-medium text-fg">
                {subject.name} · {subject.chapters.length} chapters
              </summary>
              <ul className="mb-2 flex flex-col gap-1">
                {subject.chapters.map((chapter) => (
                  <li key={chapter.id} className="text-sm text-muted">
                    <span className="text-fg">{chapter.name}</span> · {chapter.part}
                  </li>
                ))}
              </ul>
              {subject.omitted.map((line) => (
                <p key={line} className="mb-2 text-sm text-muted">
                  {line}
                </p>
              ))}
            </details>
          ))}
        </div>
      </section>

      <Sources />

      <button
        type="button"
        disabled={ids.length === 0 || problems.length > 0}
        onClick={() => confirm(stream, ids)}
        className="mt-6 min-h-11 rounded-full bg-fg px-5 text-sm font-medium text-bg disabled:opacity-40"
      >
        Build my plan
      </button>
    </main>
  );
}

function SubjectGroup({
  title,
  subjects,
  ids,
  onToggle,
}: {
  title: string;
  subjects: Subject[];
  ids: string[];
  onToggle: (id: string) => void;
}) {
  return (
    <fieldset className="mt-6">
      <legend className="text-sm font-medium text-fg">{title}</legend>
      <div className="mt-3 flex flex-wrap gap-2">
        {subjects.map((subject) => {
          const on = ids.includes(subject.id);
          return (
            <button
              key={subject.id}
              type="button"
              aria-pressed={on}
              onClick={() => onToggle(subject.id)}
              className={`min-h-11 rounded-full border px-3 py-2 text-left text-sm ${on ? "border-fg bg-surface-2 text-fg" : "border-border bg-surface text-muted"}`}
            >
              <span className="mr-2 inline-block size-2.5 rounded-full align-middle" style={{ background: `var(--color-${subject.token})` }} />
              {subject.short}
              <span className="ml-2 text-xs">{formatDay(subject.examDate)}</span>
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}

function Sources() {
  return (
    <section className="mt-8">
      <h2 className="font-serif text-2xl text-fg">Sources</h2>
      <ul className="mt-3 flex flex-col gap-3">
        {SOURCES.map((source) => (
          <li key={source.href} className="text-sm">
            <a className="font-medium text-fg underline decoration-border underline-offset-4" href={source.href} target="_blank" rel="noreferrer">
              {source.label}
            </a>
            <p className="mt-1 text-muted">{source.note}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}

function completion(subjects: Subject[], chapters: Record<string, ChapterProgress>): number {
  const all = subjects.flatMap((subject) => subject.chapters);
  if (all.length === 0) return 0;
  const score = all.reduce((sum, chapter) => {
    const status = chapters[chapter.id]?.status ?? "not_started";
    if (status === "revised") return sum + 1;
    if (status === "learning") return sum + 0.5;
    return sum;
  }, 0);
  return Math.round((score / all.length) * 100);
}

function subjectCompletion(subject: Subject, chapters: Record<string, ChapterProgress>): number {
  return completion([subject], chapters);
}

function nextUpcoming(subjects: Subject[], now: Date): Subject | undefined {
  const t = now.getTime();
  return subjects.find((subject) => new Date(`${subject.examDate}T${subject.end}:00+05:30`).getTime() >= t);
}

function streakOf(plan: DayPlan[], checks: Record<string, boolean>, today: string): number {
  const byDate = new Map(plan.map((day) => [day.date, day]));
  const counted = (iso: string) => {
    const day = byDate.get(iso);
    if (!day) return false;
    return day.blocks.some((block) => block.checkable && checks[block.id]);
  };
  let cursor = today;
  if (!counted(cursor)) {
    if (cursor <= PLAN_START) return 0;
    cursor = addDays(cursor, -1);
  }
  let count = 0;
  while (counted(cursor)) {
    count += 1;
    cursor = addDays(cursor, -1);
    if (cursor < PLAN_START) break;
  }
  return count;
}

function Dashboard() {
  const now = useNow();
  const stream = useDesk((s) => s.stream);
  const subjectIds = useDesk((s) => s.subjectIds);
  const chapters = useDesk((s) => s.chapters);
  const checks = useDesk((s) => s.checks);
  const mocks = useDesk((s) => s.mocks);
  const reopen = useDesk((s) => s.reopen);
  const toggleCheck = useDesk((s) => s.toggleCheck);
  const setStatus = useDesk((s) => s.setStatus);
  const toggleDifficult = useDesk((s) => s.toggleDifficult);
  const addMock = useDesk((s) => s.addMock);
  const removeMock = useDesk((s) => s.removeMock);
  const resetProgress = useDesk((s) => s.resetProgress);

  const subjects = useMemo(() => subjectsFromIds(subjectIds), [subjectIds]);
  const plan = useMemo(() => generatePlan(subjectIds), [subjectIds]);
  const tight = backToBack(subjects);
  const [picked, setPicked] = useState<string | null>(null);
  const [openSubject, setOpenSubject] = useState<string | null>(null);

  const todayISO = now ? isoFromDate(now) : plan[0]?.date ?? PLAN_START;
  const activeISO = picked ?? todayISO;
  const index = plan.findIndex((day) => day.date === activeISO);
  const safeIndex = index === -1 ? (activeISO < (plan[0]?.date ?? activeISO) ? 0 : Math.max(0, plan.length - 1)) : index;
  const day = plan[safeIndex];
  const upcoming = now ? nextUpcoming(subjects, now) : subjects[0];
  const days = upcoming && now ? Math.max(0, daysBetween(todayISO, upcoming.examDate)) : 0;
  const percent = completion(subjects, chapters);
  const streak = streakOf(plan, checks, todayISO);
  const focusOpen = openSubject ?? day?.focusSubjectId ?? subjects[0]?.id ?? null;

  const done = day ? day.blocks.filter((block) => block.checkable && checks[block.id]).length : 0;
  const total = day ? day.blocks.filter((block) => block.checkable).length : 0;
  const weak = subjects.flatMap((subject) =>
    subject.chapters
      .filter((chapter) => chapters[chapter.id]?.difficult)
      .map((chapter) => ({ subject, chapter })),
  );

  const hoursLeft = upcoming && now ? examHours(upcoming, now) : null;

  return (
    <>
      <main className="no-print mx-auto max-w-6xl px-4 py-6 pb-20">
        <header className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-sm text-muted">Desk 12 · {streamLabel(stream)} · final datesheet</p>
            <h1 className="font-serif text-4xl text-fg">Study desk</h1>
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => window.print()} className="inline-flex min-h-11 items-center gap-2 rounded-full bg-fg px-4 text-sm font-medium text-bg">
              <Printer className="size-4" aria-hidden="true" />
              Print my plan
            </button>
            <button type="button" onClick={reopen} className="min-h-11 rounded-full border border-border px-4 text-sm text-fg">
              Edit subjects
            </button>
          </div>
        </header>

        {tight.length > 0 && (
          <p className="mt-4 flex gap-2 rounded-2xl border border-border bg-surface px-3 py-3 text-sm text-fg">
            <TriangleAlert className="mt-0.5 size-4 shrink-0 text-paint" aria-hidden="true" />
            <span>
              {tight.map((pair) =>
                pair.freeDays === 0
                  ? `${pair.b.short} is the day after ${pair.a.short}. There is no full day between them, so ${pair.b.short} is revised before ${pair.a.short}'s paper. The evening of ${formatDay(pair.a.examDate)} is only a short glance.`
                  : `${pair.a.short} and ${pair.b.short} have only one free day between them.`,
              ).join(" ")}
            </span>
          </p>
        )}

        <section className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat
            icon={<CalendarDays className="size-4" aria-hidden="true" />}
            label="Days left"
            value={upcoming ? (days === 0 ? "Today" : String(days)) : "Done"}
            detail={
              upcoming
                ? days === 0 && hoursLeft != null
                  ? `${hoursLeft} until ${upcoming.short} starts`
                  : `until ${upcoming.short}`
                : "Every paper in this set is over"
            }
          />
          <Stat
            icon={<BookOpen className="size-4" aria-hidden="true" />}
            label="Syllabus completed"
            value={`${percent}%`}
            detail="Revised counts full. Learning counts half."
          />
          <Stat
            icon={<CalendarDays className="size-4" aria-hidden="true" />}
            label="Next exam"
            value={upcoming ? upcoming.short : "—"}
            detail={upcoming ? `${formatFull(upcoming.examDate)} · 10:30 am` : "Nothing left on this datesheet"}
          />
          <Stat
            icon={<Flame className="size-4" aria-hidden="true" />}
            label="Study streak"
            value={String(streak)}
            detail={streak === 1 ? "day with a ticked block" : "days with a ticked block"}
          />
        </section>

        <section className="mt-6">
          <h2 className="text-sm font-medium tracking-wide text-muted uppercase">Exam timeline</h2>
          <ol className="mt-3 flex items-center gap-2 overflow-x-auto pb-2">
            {subjects.map((subject, i) => {
              const following = subjects[i + 1];
              const free = following ? daysBetween(subject.examDate, following.examDate) - 1 : null;
              const isNext = upcoming?.id === subject.id;
              return (
                <li key={subject.id} className="flex items-center gap-2">
                  <div
                    className={`min-w-40 rounded-2xl border bg-surface px-3 py-3 ${isNext ? "border-fg" : "border-border"}`}
                    style={{ boxShadow: `inset 0 -3px 0 var(--color-${subject.token})` }}
                  >
                    <p className="text-xs text-muted">{formatDay(subject.examDate)}</p>
                    <p className="font-medium text-fg">{subject.short}</p>
                    <p className="text-xs text-muted">{subject.end === "12:30" ? "10:30–12:30" : "10:30–1:30"}</p>
                    {isNext && <p className="mt-1 text-xs font-medium text-fg">Next</p>}
                  </div>
                  {free != null && (
                    <span className="max-w-24 text-xs text-muted">
                      {free === 0 ? "Back to back" : `${free} gap day${free === 1 ? "" : "s"}`}
                    </span>
                  )}
                </li>
              );
            })}
          </ol>
        </section>

        <div className="mt-6 grid gap-4 lg:grid-cols-5">
          <section className="lg:col-span-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-serif text-2xl text-fg">{day && day.date === todayISO ? "Today's plan" : "Day plan"}</h2>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  aria-label="Previous day"
                  disabled={safeIndex <= 0}
                  onClick={() => setPicked(plan[safeIndex - 1]?.date ?? null)}
                  className="inline-flex size-11 items-center justify-center rounded-full border border-border text-fg disabled:opacity-40"
                >
                  <ChevronLeft className="size-4" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() => setPicked(null)}
                  className="min-h-11 rounded-full border border-border px-3 text-sm text-fg"
                >
                  Today
                </button>
                <button
                  type="button"
                  aria-label="Next day"
                  disabled={safeIndex >= plan.length - 1}
                  onClick={() => setPicked(plan[safeIndex + 1]?.date ?? null)}
                  className="inline-flex size-11 items-center justify-center rounded-full border border-border text-fg disabled:opacity-40"
                >
                  <ChevronRight className="size-4" aria-hidden="true" />
                </button>
              </div>
            </div>
            {day && (
              <div className="mt-3 rounded-2xl border border-border bg-surface p-4">
                <p className="text-sm text-muted">{formatFull(day.date)}</p>
                <p className="mt-1 font-serif text-2xl text-fg">{day.title}</p>
                <p className="mt-1 text-sm text-muted">{day.note}</p>
                <p className="mt-2 text-sm text-fg">
                  {done} of {total} blocks ticked
                  {day.lighter ? " · lighter day" : ""} · {phaseLabel(day.phase)}
                </p>
                <ul className="mt-4 flex flex-col gap-2">
                  {day.blocks.map((block) => (
                    <BlockRow key={block.id} block={block} checked={Boolean(checks[block.id])} onToggle={() => toggleCheck(block)} />
                  ))}
                </ul>
              </div>
            )}
          </section>

          <section className="lg:col-span-2">
            <h2 className="font-serif text-2xl text-fg">Subjects</h2>
            <ul className="mt-3 grid grid-cols-2 gap-2">
              {subjects.map((subject) => {
                const pct = subjectCompletion(subject, chapters);
                const learned = subject.chapters.filter((chapter) => (chapters[chapter.id]?.status ?? "not_started") !== "not_started").length;
                return (
                  <li key={subject.id}>
                    <button
                      type="button"
                      onClick={() => setOpenSubject(subject.id)}
                      className="flex w-full min-h-11 flex-col items-start rounded-2xl border border-border bg-surface p-3 text-left"
                    >
                      <Ring token={subject.token} pct={pct} />
                      <span className="mt-2 font-medium text-fg">{subject.short}</span>
                      <span className="text-xs text-muted">
                        {learned}/{subject.chapters.length} started · {formatDay(subject.examDate)}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>
        </div>

        <section className="mt-8">
          <h2 className="font-serif text-2xl text-fg">Chapter tracker</h2>
          <p className="mt-1 text-sm text-muted">Ticking a learn block moves a chapter to Learning. Ticking a revise block marks it Revised. You can override either.</p>
          <div className="mt-3 flex flex-col gap-2">
            {subjects.map((subject) => (
              <details key={subject.id} className="rounded-2xl border border-border bg-surface px-3 py-2" open={focusOpen === subject.id} onToggle={(event) => {
                const el = event.currentTarget;
                if (el.open) setOpenSubject(subject.id);
                else setOpenSubject(focusOpen === subject.id ? "" : focusOpen);
              }}>
                <summary className="flex min-h-11 cursor-pointer items-center justify-between gap-3 py-2">
                  <span className="font-medium text-fg">
                    <span className="mr-2 inline-block size-2.5 rounded-full" style={{ background: `var(--color-${subject.token})` }} />
                    {subject.name}
                  </span>
                  <span className="text-sm text-muted">{subjectCompletion(subject, chapters)}%</span>
                </summary>
                <ul className="mb-3 flex flex-col gap-3">
                  {subject.chapters.map((chapter) => {
                    const progress = chapters[chapter.id] ?? { status: "not_started" as const, difficult: false };
                    return (
                      <li key={chapter.id} className="border-t border-border pt-3">
                        <p className="text-sm font-medium text-fg">{chapter.name}</p>
                        <p className="text-xs text-muted">{chapter.part}</p>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {(Object.keys(STATUS_LABEL) as ChapterStatus[]).map((status) => (
                            <button
                              key={status}
                              type="button"
                              aria-pressed={progress.status === status}
                              onClick={() => setStatus(chapter.id, status)}
                              className={`min-h-11 rounded-full border px-3 text-sm ${progress.status === status ? "border-fg bg-surface-2 text-fg" : "border-border text-muted"}`}
                            >
                              {STATUS_LABEL[status]}
                            </button>
                          ))}
                          <button
                            type="button"
                            aria-pressed={progress.difficult}
                            onClick={() => toggleDifficult(chapter.id)}
                            className={`min-h-11 rounded-full border px-3 text-sm ${progress.difficult ? "border-paint text-fg" : "border-border text-muted"}`}
                          >
                            {progress.difficult ? "Difficult" : "Mark difficult"}
                          </button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
                {subject.omitted.length > 0 && (
                  <div className="mb-3 rounded-xl bg-surface-2 px-3 py-2">
                    {subject.omitted.map((line) => (
                      <p key={line} className="text-sm text-muted">
                        Not in this course: {line}
                      </p>
                    ))}
                  </div>
                )}
              </details>
            ))}
          </div>
        </section>

        <div className="mt-8 grid gap-4 lg:grid-cols-2">
          <section className="rounded-2xl border border-border bg-surface p-4">
            <h2 className="font-serif text-2xl text-fg">Weak topics</h2>
            {weak.length === 0 ? (
              <p className="mt-2 text-sm text-muted">Nothing marked difficult yet. Use “Mark difficult” on a chapter and it will sit here.</p>
            ) : (
              <ul className="mt-3 flex flex-col gap-2">
                {weak.map(({ subject, chapter }) => (
                  <li key={chapter.id} className="flex items-center justify-between gap-3 rounded-xl bg-surface-2 px-3 py-3">
                    <span>
                      <span className="block text-sm font-medium text-fg">{chapter.name}</span>
                      <span className="text-xs text-muted">{subject.short}</span>
                    </span>
                    <button type="button" onClick={() => toggleDifficult(chapter.id)} className="min-h-11 rounded-full border border-border px-3 text-sm text-fg">
                      Remove
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </section>
          <MockPanel subjects={subjects} mocks={mocks} today={todayISO} addMock={addMock} removeMock={removeMock} />
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
          <button type="button" onClick={resetProgress} className="inline-flex min-h-11 items-center gap-2 rounded-full border border-border px-4 text-sm text-muted">
            <RotateCcw className="size-4" aria-hidden="true" />
            Clear ticks and scores
          </button>
          <p className="text-xs text-muted">Saved on this device. Three phases: learn, revise, then mocks. Sundays are a full past paper. Saturdays are the light day.</p>
        </div>
        <Sources />
      </main>
      <PrintSheet plan={plan} subjects={subjects} stream={stream} />
    </>
  );
}

function examHours(subject: Subject, now: Date): string | null {
  const start = new Date(`${subject.examDate}T10:30:00+05:30`).getTime();
  const diff = start - now.getTime();
  if (diff <= 0) return null;
  const hours = Math.floor(diff / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  if (hours >= 48) return null;
  return `${hours}h ${mins}m`;
}

function streamLabel(stream: StreamId): string {
  if (stream === "science") return "Science";
  if (stream === "humanities") return "Humanities";
  return "Commerce";
}

function phaseLabel(phase: DayPlan["phase"]): string {
  if (phase === "learn") return "Learn phase";
  if (phase === "revise") return "Revise phase";
  if (phase === "mock") return "Mock phase";
  if (phase === "gap") return "Gap days, next paper only";
  if (phase === "revision-day") return "Revision day";
  return "Exam day";
}

function Stat({ icon, label, value, detail }: { icon: ReactNode; label: string; value: string; detail: string }) {
  return (
    <article className="rounded-2xl border border-border bg-surface p-4">
      <p className="flex items-center gap-2 text-xs font-medium tracking-wide text-muted uppercase">
        {icon}
        {label}
      </p>
      <p className="mt-2 font-serif text-4xl text-fg">{value}</p>
      <p className="mt-1 text-sm text-muted">{detail}</p>
    </article>
  );
}

function Ring({ token, pct }: { token: string; pct: number }) {
  const r = 15.5;
  const c = 2 * Math.PI * r;
  const dash = (Math.max(0, Math.min(100, pct)) / 100) * c;
  return (
    <svg viewBox="0 0 36 36" className="size-16" aria-hidden="true">
      <circle cx="18" cy="18" r={r} fill="none" stroke="var(--color-border)" strokeWidth="3" />
      <circle
        cx="18"
        cy="18"
        r={r}
        fill="none"
        stroke={`var(--color-${token})`}
        strokeWidth="3"
        strokeLinecap="round"
        strokeDasharray={`${dash} ${c}`}
        transform="rotate(-90 18 18)"
      />
      <text x="18" y="19" textAnchor="middle" dominantBaseline="middle" fill="var(--color-fg)" fontSize="7" fontFamily="Outfit, sans-serif">
        {pct}%
      </text>
    </svg>
  );
}

function BlockRow({ block, checked, onToggle }: { block: PlanBlock; checked: boolean; onToggle: () => void }) {
  const token = block.subjectId ? (SUBJECTS.find((s) => s.id === block.subjectId)?.token ?? "eng") : null;
  if (!block.checkable) {
    return (
      <li className="rounded-xl bg-bg px-3 py-2 text-sm text-muted">
        <span className="text-xs">
          {block.start}–{block.end}
        </span>
        <span className="mt-0.5 block text-fg">{block.title}</span>
        <span className="block">{block.detail}</span>
      </li>
    );
  }
  return (
    <li>
      <label
        className="flex min-h-11 cursor-pointer gap-3 rounded-xl bg-surface-2 px-3 py-3"
        style={token ? { boxShadow: `inset 3px 0 0 var(--color-${token})` } : undefined}
      >
        <input type="checkbox" checked={checked} onChange={onToggle} className="mt-1 size-5 shrink-0 accent-current" />
        <span>
          <span className="text-xs text-muted">
            {block.start}–{block.end}
            {checked ? " · done" : ""}
          </span>
          <span className={`mt-0.5 block font-medium ${checked ? "text-muted line-through" : "text-fg"}`}>{block.title}</span>
          <span className="block text-sm text-muted">{block.detail}</span>
        </span>
      </label>
    </li>
  );
}

function MockPanel({
  subjects,
  mocks,
  today,
  addMock,
  removeMock,
}: {
  subjects: Subject[];
  mocks: MockScore[];
  today: string;
  addMock: (mock: Omit<MockScore, "id">) => void;
  removeMock: (id: string) => void;
}) {
  const [subjectId, setSubjectId] = useState(subjects[0]?.id ?? "");
  const [score, setScore] = useState("");
  const [total, setTotal] = useState(String(subjects[0]?.paperMarks ?? 80));
  const [date, setDate] = useState(today);
  const [filter, setFilter] = useState(subjects[0]?.id ?? "all");

  const rows = mocks
    .filter((mock) => filter === "all" || mock.subjectId === filter)
    .slice()
    .sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id))
    .map((mock, i) => ({
      label: `${i + 1}`,
      pct: Math.round((mock.score / mock.total) * 100),
      note: `${mock.score}/${mock.total}`,
    }));

  function onSubject(id: string) {
    setSubjectId(id);
    const subject = subjects.find((item) => item.id === id);
    if (subject) setTotal(String(subject.paperMarks));
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    const s = Number(score);
    const t = Number(total);
    if (!subjectId || !Number.isFinite(s) || !Number.isFinite(t) || t <= 0 || s < 0 || s > t) return;
    addMock({ subjectId, score: s, total: t, date });
    setScore("");
  }

  return (
    <section className="rounded-2xl border border-border bg-surface p-4">
      <h2 className="font-serif text-2xl text-fg">Mock tests</h2>
      <p className="mt-1 text-sm text-muted">Log a Sunday paper or any timed test. The line is your percentage.</p>
      <form onSubmit={submit} className="mt-3 grid grid-cols-2 gap-2">
        <label className="col-span-2 text-sm text-muted">
          Subject
          <select value={subjectId} onChange={(event) => onSubject(event.target.value)} className="mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg">
            {subjects.map((subject) => (
              <option key={subject.id} value={subject.id}>
                {subject.name}
              </option>
            ))}
          </select>
        </label>
        <label className="text-sm text-muted">
          Score
          <input value={score} onChange={(event) => setScore(event.target.value)} inputMode="decimal" className="mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg" />
        </label>
        <label className="text-sm text-muted">
          Out of
          <input value={total} onChange={(event) => setTotal(event.target.value)} inputMode="decimal" className="mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg" />
        </label>
        <label className="col-span-2 text-sm text-muted">
          Date
          <input type="date" value={date} onChange={(event) => setDate(event.target.value)} className="mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg" />
        </label>
        <button type="submit" className="col-span-2 min-h-11 rounded-full bg-fg text-sm font-medium text-bg">
          Add score
        </button>
      </form>
      <label className="mt-4 block text-sm text-muted">
        Chart subject
        <select value={filter} onChange={(event) => setFilter(event.target.value)} className="mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg">
          <option value="all">All papers</option>
          {subjects.map((subject) => (
            <option key={subject.id} value={subject.id}>
              {subject.name}
            </option>
          ))}
        </select>
      </label>
      <div className="mt-3">
        {rows.length < 2 ? (
          <p className="text-sm text-muted">Add at least two scores to see the line move.</p>
        ) : (
          <MockChart rows={rows} />
        )}
      </div>
      {mocks.length > 0 && (
        <ul className="mt-3 flex flex-col gap-2">
          {mocks
            .slice()
            .reverse()
            .map((mock) => {
              const subject = subjects.find((item) => item.id === mock.subjectId);
              return (
                <li key={mock.id} className="flex items-center justify-between gap-2 text-sm">
                  <span className="text-fg">
                    {subject?.short ?? "Paper"} · {mock.score}/{mock.total} · {formatDay(mock.date)}
                  </span>
                  <button type="button" onClick={() => removeMock(mock.id)} className="min-h-11 px-2 text-muted">
                    Delete
                  </button>
                </li>
              );
            })}
        </ul>
      )}
    </section>
  );
}

function MockChart({ rows }: { rows: { label: string; pct: number }[] }) {
  const [lib, setLib] = useState<typeof import("recharts") | null>(null);
  useEffect(() => {
    let live = true;
    void import("recharts").then((mod) => {
      if (live) setLib(mod);
    });
    return () => {
      live = false;
    };
  }, []);
  if (!lib) return <p className="text-sm text-muted">Chart is loading.</p>;
  const { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } = lib;
  return (
    <div className="h-56 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={rows}>
          <CartesianGrid stroke="var(--color-border)" strokeDasharray="3 3" />
          <XAxis dataKey="label" stroke="var(--color-muted)" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
          <YAxis domain={[0, 100]} stroke="var(--color-muted)" tick={{ fill: "var(--color-muted)", fontSize: 12 }} />
          <Tooltip
            contentStyle={{
              background: "var(--color-surface-2)",
              border: "1px solid var(--color-border)",
              borderRadius: 12,
              color: "var(--color-fg)",
            }}
          />
          <Line type="monotone" dataKey="pct" name="Percent" stroke="var(--color-eng)" strokeWidth={2} dot={{ r: 3 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function PrintSheet({ plan, subjects, stream }: { plan: DayPlan[]; subjects: Subject[]; stream: StreamId }) {
  const weeks = useMemo(() => weekRows(plan), [plan]);
  return (
    <section className="print-sheet px-4 py-4">
      <h1 className="font-serif text-2xl">Desk 12 · {streamLabel(stream)} · CBSE 2027</h1>
      <p>
        Plan from {formatFull(PLAN_START)} to {subjects.at(-1) ? formatFull(subjects.at(-1)!.examDate) : "the last paper"}. Eight hours on full days, lighter
        Saturdays, a past paper every Sunday, one revision day before each exam. Gap days belong to the next paper only.
      </p>
      <p>
        {subjects.map((subject) => `${subject.short} ${formatDay(subject.examDate)}`).join(" · ")}
      </p>
      <table>
        <thead>
          <tr>
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((label) => (
              <th key={label}>{label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {weeks.map((week) => (
            <tr key={week.start}>
              {week.days.map((day, i) => (
                <td key={`${week.start}-${i}`}>
                  {day ? (
                    <>
                      <strong>
                        {parseISODate(day.date).getDate()} {day.phase === "exam" ? "EXAM" : day.lighter ? "Light" : day.phase}
                      </strong>
                      <br />
                      {day.title}
                    </>
                  ) : null}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

function weekRows(plan: DayPlan[]): { start: string; days: (DayPlan | null)[] }[] {
  if (plan.length === 0) return [];
  const byDate = new Map(plan.map((day) => [day.date, day]));
  const first = plan[0].date;
  const dow = parseISODate(first).getDay();
  const offset = dow === 0 ? -6 : 1 - dow;
  let cursor = addDays(first, offset);
  const last = plan[plan.length - 1].date;
  const weeks: { start: string; days: (DayPlan | null)[] }[] = [];
  while (cursor <= last) {
    const days: (DayPlan | null)[] = [];
    for (let i = 0; i < 7; i += 1) days.push(byDate.get(addDays(cursor, i)) ?? null);
    weeks.push({ start: cursor, days });
    cursor = addDays(cursor, 7);
  }
  return weeks;
}
