import {
  PLAN_START,
  SUBJECT_MAP,
  type Chapter,
  type Subject,
  subjectsFromIds,
} from "./syllabus";

export type BlockKind =
  | "learn"
  | "practice"
  | "revise"
  | "mock"
  | "pyq"
  | "recap"
  | "break"
  | "meal"
  | "rest"
  | "exam";

export type DayPhase = "learn" | "revise" | "mock" | "gap" | "revision-day" | "exam";

export type PlanBlock = {
  id: string;
  start: string;
  end: string;
  title: string;
  detail: string;
  kind: BlockKind;
  subjectId?: string;
  chapterId?: string;
  checkable: boolean;
};

export type DayPlan = {
  date: string;
  weekday: string;
  phase: DayPhase;
  title: string;
  note: string;
  lighter: boolean;
  focusSubjectId?: string;
  blocks: PlanBlock[];
};

const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function parseISODate(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function isoFromDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function addDays(iso: string, n: number): string {
  const d = parseISODate(iso);
  d.setDate(d.getDate() + n);
  return isoFromDate(d);
}

export function daysBetween(a: string, b: string): number {
  return Math.round((parseISODate(b).getTime() - parseISODate(a).getTime()) / 86400000);
}

export function formatDay(iso: string): string {
  const d = parseISODate(iso);
  return `${WEEKDAYS[d.getDay()].slice(0, 3)}, ${d.getDate()} ${MONTHS[d.getMonth()]}`;
}

export function formatFull(iso: string): string {
  const d = parseISODate(iso);
  return `${WEEKDAYS[d.getDay()]}, ${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

function range(start: string, end: string): string[] {
  if (start > end) return [];
  const out: string[] = [];
  let cur = start;
  while (cur <= end) {
    out.push(cur);
    cur = addDays(cur, 1);
  }
  return out;
}

function isSun(iso: string): boolean {
  return parseISODate(iso).getDay() === 0;
}
function isSat(iso: string): boolean {
  return parseISODate(iso).getDay() === 6;
}

type QItem = { id: string; left: number };
type Role =
  | { type: "exam"; subjectId: string }
  | { type: "revision"; subjectId: string }
  | { type: "shared"; phase: "learn" | "revise" | "mock" }
  | { type: "gap"; subjectId: string };

type Item = {
  start: string;
  end: string;
  slot?: "learn" | "practice" | "revise" | "mock" | "pyq" | "recap";
  fixed?: { kind: BlockKind; title: string; detail: string };
};

const SLEEP = "Sleep 10:30 pm to 6:30 am (8 hours).";

function brk(start: string, end: string, long = false): Item {
  return {
    start,
    end,
    fixed: {
      kind: "break",
      title: long ? "Long break" : "Break",
      detail: long ? "Snack, water, 25 minutes away from the desk." : "Stand, sip water, ten minutes off the page.",
    },
  };
}

function weekdayItems(mode: "learn" | "revise" | "mock"): Item[] {
  const main: Item["slot"] = mode === "learn" ? "learn" : mode === "revise" ? "revise" : "mock";
  const mid: Item["slot"] = mode === "learn" ? "practice" : mode === "mock" ? "revise" : "mock";
  const late: Item["slot"] = mode === "learn" ? "revise" : "revise";
  return [
    { start: "7:00", end: "7:50", slot: main },
    brk("7:50", "8:00"),
    { start: "8:00", end: "8:50", slot: main },
    brk("8:50", "9:00"),
    { start: "9:00", end: "9:50", slot: main },
    brk("9:50", "10:00"),
    { start: "10:00", end: "10:50", slot: main },
    brk("10:50", "11:15", true),
    { start: "11:15", end: "12:05", slot: mode === "mock" ? "revise" : main },
    brk("12:05", "12:15"),
    { start: "12:15", end: "13:05", slot: mid },
    { start: "13:05", end: "14:00", fixed: { kind: "meal", title: "Lunch", detail: "Eat away from the desk. No screens if you can help it." } },
    { start: "14:00", end: "14:50", slot: late },
    brk("14:50", "15:00"),
    { start: "15:00", end: "15:50", slot: mode === "learn" ? "learn" : "revise" },
    brk("15:50", "16:00"),
    { start: "16:00", end: "16:50", slot: mode === "learn" ? "learn" : "revise" },
    { start: "16:50", end: "17:30", fixed: { kind: "rest", title: "Walk", detail: "Twenty to thirty minutes outside or around the house." } },
    { start: "17:30", end: "18:00", slot: "recap" },
  ];
}

function saturdayItems(mode: "learn" | "revise" | "mock"): Item[] {
  const slot: Item["slot"] = mode === "learn" ? "learn" : mode === "mock" ? "mock" : "revise";
  return [
    { start: "8:00", end: "8:50", slot },
    brk("8:50", "9:00"),
    { start: "9:00", end: "9:50", slot },
    brk("9:50", "10:00"),
    { start: "10:00", end: "10:50", slot },
    brk("10:50", "11:15", true),
    { start: "11:15", end: "12:05", slot: mode === "learn" ? "practice" : "revise" },
    brk("12:05", "12:15"),
    { start: "12:15", end: "13:05", slot: "revise" },
    {
      start: "13:05",
      end: "18:00",
      fixed: {
        kind: "rest",
        title: "Afternoon off",
        detail: "Lighter catch-up day. Stop after lunch unless a chapter is still untouched.",
      },
    },
  ];
}

function sundayItems(): Item[] {
  return [
    { start: "7:00", end: "10:00", slot: "pyq" },
    brk("10:00", "10:20", true),
    { start: "10:20", end: "11:10", slot: "revise" },
    brk("11:10", "11:20"),
    { start: "11:20", end: "12:10", slot: "revise" },
    { start: "12:10", end: "13:40", fixed: { kind: "meal", title: "Lunch", detail: "Longer lunch after the paper. Eat, then a short walk." } },
    { start: "14:00", end: "14:50", slot: "revise" },
    brk("14:50", "15:00"),
    { start: "15:00", end: "15:50", slot: "revise" },
    brk("15:50", "16:00"),
    { start: "16:00", end: "16:50", slot: "practice" },
    { start: "17:30", end: "18:00", slot: "recap" },
  ];
}

function revisionItems(sunday: boolean): Item[] {
  if (sunday) {
    return [
      { start: "7:00", end: "10:00", slot: "pyq" },
      brk("10:00", "10:20", true),
      { start: "10:20", end: "11:10", slot: "revise" },
      brk("11:10", "11:20"),
      { start: "11:20", end: "12:10", slot: "revise" },
      { start: "12:10", end: "13:30", fixed: { kind: "meal", title: "Lunch", detail: "Keep it light. This is the last full day before the paper." } },
      { start: "13:30", end: "14:20", slot: "revise" },
      brk("14:20", "14:30"),
      { start: "14:30", end: "15:20", slot: "revise" },
      brk("15:20", "15:30"),
      { start: "15:30", end: "16:20", slot: "mock" },
      { start: "16:20", end: "17:00", fixed: { kind: "rest", title: "Stop", detail: "Pack your bag. No new chapter after this." } },
    ];
  }
  return [
    { start: "7:00", end: "7:50", slot: "revise" },
    brk("7:50", "8:00"),
    { start: "8:00", end: "8:50", slot: "revise" },
    brk("8:50", "9:00"),
    { start: "9:00", end: "9:50", slot: "revise" },
    brk("9:50", "10:00"),
    { start: "10:00", end: "10:50", slot: "revise" },
    brk("10:50", "11:15", true),
    { start: "11:15", end: "12:05", slot: "revise" },
    brk("12:05", "12:15"),
    { start: "12:15", end: "13:05", slot: "revise" },
    { start: "13:05", end: "14:00", fixed: { kind: "meal", title: "Lunch", detail: "Light meal. You still have a formula pass after lunch." } },
    { start: "14:00", end: "14:50", slot: "revise" },
    brk("14:50", "15:00"),
    { start: "15:00", end: "15:50", slot: "revise" },
    brk("15:50", "16:00"),
    { start: "16:00", end: "16:50", slot: "mock" },
    { start: "16:50", end: "18:00", fixed: { kind: "rest", title: "Stop", detail: "Bag ready. Sleep on time. No fresh chapter tonight." } },
  ];
}

function unitsLeft(queues: Record<string, QItem[]>, id: string): number {
  return (queues[id] ?? []).reduce((sum, c) => sum + c.left, 0);
}

function takeChapter(queues: Record<string, QItem[]>, id: string): string | null {
  const item = (queues[id] ?? []).find((c) => c.left > 0);
  if (!item) return null;
  item.left -= 1;
  return item.id;
}

export function generatePlan(subjectIds: string[]): DayPlan[] {
  const subjects = subjectsFromIds(subjectIds);
  if (subjects.length === 0) return [];

  const byId = new Map(subjects.map((s) => [s.id, s]));
  const allowedIds = subjects.map((s) => s.id);
  const examDates = new Set(subjects.map((s) => s.examDate));
  const firstExam = subjects[0].examDate;
  const lastExam = subjects[subjects.length - 1].examDate;

  const revisionOf = new Map<string, string>();
  const takenRev = new Set<string>();
  for (const s of subjects) {
    let d = addDays(s.examDate, -1);
    while (d >= PLAN_START && (examDates.has(d) || takenRev.has(d))) d = addDays(d, -1);
    if (d >= PLAN_START) {
      takenRev.add(d);
      revisionOf.set(s.id, d);
    }
  }

  const sharedDates = range(PLAN_START, addDays(firstExam, -1)).filter(
    (d) => !examDates.has(d) && !takenRev.has(d),
  );
  const n = sharedDates.length;
  const nLearn = Math.round(n * 0.55);
  const nRev = Math.round(n * 0.25);
  const sharedPhase = new Map<string, "learn" | "revise" | "mock">();
  sharedDates.forEach((d, i) => {
    if (i < nLearn) sharedPhase.set(d, "learn");
    else if (i < nLearn + nRev) sharedPhase.set(d, "revise");
    else sharedPhase.set(d, "mock");
  });

  const roles = new Map<string, Role>();
  for (const d of range(PLAN_START, lastExam)) {
    const exam = subjects.find((s) => s.examDate === d);
    if (exam) {
      roles.set(d, { type: "exam", subjectId: exam.id });
      continue;
    }
    const rev = subjects.find((s) => revisionOf.get(s.id) === d);
    if (rev) {
      roles.set(d, { type: "revision", subjectId: rev.id });
      continue;
    }
    if (d < firstExam) {
      roles.set(d, { type: "shared", phase: sharedPhase.get(d) ?? "mock" });
      continue;
    }
    const next = subjects.find((s) => s.examDate > d);
    if (next) roles.set(d, { type: "gap", subjectId: next.id });
  }

  const queues: Record<string, QItem[]> = {};
  const chapterOf = new Map<string, Chapter>();
  for (const s of subjects) {
    queues[s.id] = s.chapters.map((c) => ({ id: c.id, left: c.units }));
    for (const c of s.chapters) chapterOf.set(c.id, c);
  }
  const reviseCursor: Record<string, number> = {};

  function urgency(id: string, today: string): number {
    const sub = byId.get(id);
    if (!sub) return 0;
    return sub.hardness / Math.max(1, daysBetween(today, sub.examDate));
  }

  function nextRevise(id: string): Chapter | undefined {
    const sub = byId.get(id);
    if (!sub || sub.chapters.length === 0) return undefined;
    const i = reviseCursor[id] ?? 0;
    reviseCursor[id] = i + 1;
    return sub.chapters[i % sub.chapters.length];
  }

  function pickLearn(pool: string[], today: string, used: Record<string, number>, cap: number): string | null {
    let best: string | null = null;
    let bestScore = 0;
    for (const id of pool) {
      const left = unitsLeft(queues, id);
      if (left <= 0) continue;
      let score = left * urgency(id, today);
      if ((used[id] ?? 0) >= cap) score *= 0.12;
      if (score > bestScore) {
        bestScore = score;
        best = id;
      }
    }
    return best;
  }

  function pickRevise(pool: string[], today: string, used: Record<string, number>, cap: number): string {
    const ranked = [...pool].sort((a, b) => urgency(b, today) - urgency(a, today));
    const open = ranked.find((id) => (used[id] ?? 0) < cap);
    return open ?? ranked[0];
  }

  let sundayCount = 0;
  const days: DayPlan[] = [];

  for (const date of range(PLAN_START, lastExam)) {
    const role = roles.get(date);
    if (!role) continue;
    const weekday = WEEKDAYS[parseISODate(date).getDay()];

    if (role.type === "exam") {
      const sub = byId.get(role.subjectId)!;
      const next = subjects.find((s) => s.examDate > date);
      const blocks: PlanBlock[] = [
        {
          id: `${date}-prep`,
          start: "7:30",
          end: "10:00",
          title: "Exam morning",
          detail: `Admit card, bottle, pen. Reach early. ${sub.name} starts at 10:30 am. No new topic.`,
          kind: "rest",
          checkable: false,
        },
        {
          id: `${date}-exam`,
          start: "10:30",
          end: sub.end,
          title: `Board exam · ${sub.name}`,
          detail: `Code ${sub.code}. ${sub.marks}. Tick this when you are back.`,
          kind: "exam",
          subjectId: sub.id,
          checkable: true,
        },
      ];
      if (next && daysBetween(date, next.examDate) === 1) {
        const ch1 = nextRevise(next.id);
        const ch2 = nextRevise(next.id);
        blocks.push(
          {
            id: `${date}-g1`,
            start: "16:30",
            end: "17:20",
            title: ch1 ? `Short glance · ${ch1.name}` : `Short glance · ${next.short}`,
            detail: "Only recall. The next paper is tomorrow morning. Do not open a new chapter.",
            kind: "revise",
            subjectId: next.id,
            chapterId: ch1?.id,
            checkable: true,
          },
          {
            id: `${date}-g2`,
            start: "17:30",
            end: "18:10",
            title: ch2 ? `Formulas and names · ${ch2.name}` : `Formulas · ${next.short}`,
            detail: "One page of points, then stop and sleep.",
            kind: "revise",
            subjectId: next.id,
            chapterId: ch2?.id,
            checkable: true,
          },
        );
      } else if (next) {
        blocks.push({
          id: `${date}-rest`,
          start: "16:00",
          end: "18:00",
          title: "Rest",
          detail: `You earned the evening. ${next.short} starts properly tomorrow. Sleep on time.`,
          kind: "rest",
          checkable: false,
        });
      }
      days.push({
        date,
        weekday,
        phase: "exam",
        title: `Exam · ${sub.name}`,
        note: `Paper at 10:30 am, ends ${sub.end}. ${SLEEP}`,
        lighter: false,
        focusSubjectId: sub.id,
        blocks,
      });
      continue;
    }

    let pool = allowedIds;
    let mode: "learn" | "revise" | "mock" = "learn";
    let phase: DayPhase = "learn";
    let focusId = subjects[0].id;
    let title = "Study";
    let lighter = false;
    let items: Item[] = [];
    let sundayPaper: string | null = null;

    if (role.type === "revision") {
      focusId = role.subjectId;
      pool = [role.subjectId];
      phase = "revision-day";
      mode = "revise";
      reviseCursor[role.subjectId] = 0;
      const sub = byId.get(role.subjectId)!;
      title = `Revision day · ${sub.name}`;
      lighter = false;
      items = revisionItems(isSun(date));
      if (isSun(date)) sundayPaper = role.subjectId;
    } else if (role.type === "gap") {
      focusId = role.subjectId;
      pool = [role.subjectId];
      phase = "gap";
      const sub = byId.get(role.subjectId)!;
      const revDate = revisionOf.get(role.subjectId) ?? sub.examDate;
      if (unitsLeft(queues, role.subjectId) > 0) mode = "learn";
      else if (daysBetween(date, revDate) > 4) mode = "revise";
      else mode = "mock";
      title =
        mode === "learn"
          ? `Finish learning · ${sub.name}`
          : mode === "mock"
            ? `Mocks · ${sub.name}`
            : `Revise · ${sub.name}`;
    } else {
      phase = role.phase;
      mode = role.phase;
      pool = allowedIds;
      focusId = [...allowedIds].sort((a, b) => urgency(b, date) - urgency(a, date))[0];
      const focus = byId.get(focusId)!;
      title =
        role.phase === "learn"
          ? `Learn · ${focus.short} first`
          : role.phase === "revise"
            ? `Second pass · ${focus.short} first`
            : `Mock phase · ${focus.short} first`;
    }

    if (role.type !== "revision") {
      if (isSun(date)) {
        sundayCount += 1;
        const ranked = [...pool].sort((a, b) => urgency(b, date) - urgency(a, date));
        sundayPaper = sundayCount % 3 === 0 && ranked[1] ? ranked[1] : ranked[0];
        focusId = sundayPaper;
        const sub = byId.get(sundayPaper)!;
        title = `Sunday paper · ${sub.name}`;
        items = sundayItems();
        lighter = false;
        if (role.type === "shared") phase = role.phase;
      } else if (isSat(date)) {
        lighter = true;
        title = `Catch-up · ${byId.get(focusId)!.short}`;
        items = saturdayItems(mode);
      } else {
        items = weekdayItems(mode);
      }
    }

    const used: Record<string, number> = {};
    const cap = pool.length > 1 ? (lighter ? 3 : 4) : 99;
    const blocks: PlanBlock[] = items.map((item, index) => {
      const id = `${date}-${index}`;
      if (item.fixed) {
        return {
          id,
          start: item.start,
          end: item.end,
          title: item.fixed.title,
          detail: item.fixed.detail,
          kind: item.fixed.kind,
          checkable: false,
        };
      }
      const slot = item.slot ?? "learn";
      if (slot === "recap") {
        return {
          id,
          start: item.start,
          end: item.end,
          title: "Evening recap",
          detail: "Fifteen flashcards from today, then close the books. Lights out 10:30 pm.",
          kind: "recap",
          subjectId: focusId,
          checkable: true,
        };
      }
      if (slot === "pyq") {
        const sid = sundayPaper ?? focusId;
        const sub = byId.get(sid)!;
        return {
          id,
          start: item.start,
          end: item.end,
          title: `Previous year paper · ${sub.name}`,
          detail: "Full paper, timed, no notes. Treat 7:00 am as the invigilator saying you may start.",
          kind: "pyq",
          subjectId: sid,
          checkable: true,
        };
      }

      let sid = focusId;
      let chapterId: string | undefined;
      let kind: BlockKind = slot === "practice" ? "practice" : slot;

      if (slot === "learn" || slot === "practice") {
        if (sundayPaper && slot === "practice") {
          sid = sundayPaper;
          chapterId = nextRevise(sid)?.id;
          kind = "practice";
        } else {
          const picked = pickLearn(pool, date, used, cap);
          if (picked) {
            sid = picked;
            chapterId = takeChapter(queues, picked) ?? undefined;
            used[sid] = (used[sid] ?? 0) + 1;
            kind = slot === "practice" ? "practice" : "learn";
          } else {
            sid = pickRevise(pool, date, used, cap);
            chapterId = nextRevise(sid)?.id;
            used[sid] = (used[sid] ?? 0) + 1;
            kind = "revise";
          }
        }
      } else {
        sid = slot === "mock" || slot === "revise" ? pickRevise(pool, date, used, cap) : focusId;
        if (sundayPaper && (slot === "revise" || slot === "mock")) sid = sundayPaper;
        if (role.type === "revision" || role.type === "gap") sid = role.subjectId;
        if (mode === "learn" && slot === "revise" && !sundayPaper) {
          const top = Object.entries(used).sort((a, b) => b[1] - a[1])[0];
          if (top) sid = top[0];
        }
        chapterId = nextRevise(sid)?.id;
        used[sid] = (used[sid] ?? 0) + 1;
        kind = slot === "mock" ? "mock" : "revise";
      }

      const sub = byId.get(sid)!;
      const chapter = chapterId ? chapterOf.get(chapterId) : undefined;
      const name = chapter?.name ?? sub.short;
      const focus = chapter?.focus ?? "Use your notes and the marking scheme.";
      let blockTitle = `${sub.short}: ${name}`;
      let detail = focus;
      if (kind === "practice") {
        blockTitle = `Practice · ${name}`;
        detail = `Questions only, then check. ${focus}`;
      } else if (kind === "revise") {
        blockTitle = `Revise · ${name}`;
        detail = `Close the book and recall, then patch holes. ${focus}`;
      } else if (kind === "mock") {
        blockTitle = `Timed section · ${name}`;
        detail = `Exam conditions for this slice. ${focus}`;
      } else {
        blockTitle = `Learn · ${name}`;
        detail = focus;
      }
      if (!focusId) focusId = sid;
      return {
        id,
        start: item.start,
        end: item.end,
        title: blockTitle,
        detail,
        kind,
        subjectId: sid,
        chapterId,
        checkable: true,
      };
    });

    const learnedFocus = blocks.find((b) => b.checkable && b.subjectId)?.subjectId ?? focusId;
    days.push({
      date,
      weekday,
      phase,
      title,
      note: lighter
        ? `Lighter catch-up. Five study blocks, then stop. ${SLEEP}`
        : phase === "revision-day"
          ? `Full revision. Nothing new. ${SLEEP}`
          : `Eight hours in 50-minute blocks, with a 3-hour paper on Sundays. ${SLEEP}`,
      lighter,
      focusSubjectId: learnedFocus,
      blocks,
    });
  }

  return days;
}

export function backToBack(subjects: Subject[]): { a: Subject; b: Subject; freeDays: number }[] {
  const out: { a: Subject; b: Subject; freeDays: number }[] = [];
  for (let i = 0; i < subjects.length - 1; i++) {
    const freeDays = daysBetween(subjects[i].examDate, subjects[i + 1].examDate) - 1;
    if (freeDays <= 1) out.push({ a: subjects[i], b: subjects[i + 1], freeDays });
  }
  return out;
}

export function subjectById(id: string): Subject | undefined {
  return SUBJECT_MAP[id];
}
