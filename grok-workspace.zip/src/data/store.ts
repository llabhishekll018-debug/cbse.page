import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { StreamId } from "./syllabus";
import { defaultSubjectIds } from "./syllabus";
import type { BlockKind, PlanBlock } from "./plan";

export type ChapterStatus = "not_started" | "learning" | "revised";

export type ChapterProgress = {
  status: ChapterStatus;
  difficult: boolean;
};

export type MockScore = {
  id: string;
  date: string;
  subjectId: string;
  score: number;
  total: number;
};

type DeskState = {
  confirmed: boolean;
  stream: StreamId;
  subjectIds: string[];
  chapters: Record<string, ChapterProgress>;
  checks: Record<string, boolean>;
  mocks: MockScore[];
  confirm: (stream: StreamId, subjectIds: string[]) => void;
  reopen: () => void;
  toggleCheck: (block: PlanBlock) => void;
  setStatus: (chapterId: string, status: ChapterStatus) => void;
  toggleDifficult: (chapterId: string) => void;
  addMock: (mock: Omit<MockScore, "id">) => void;
  removeMock: (id: string) => void;
  resetProgress: () => void;
};

const memory = new Map<string, string>();

const storage = {
  getItem: (key: string) =>
    typeof window === "undefined" ? (memory.get(key) ?? null) : window.localStorage.getItem(key),
  setItem: (key: string, value: string) => {
    if (typeof window === "undefined") memory.set(key, value);
    else window.localStorage.setItem(key, value);
  },
  removeItem: (key: string) => {
    if (typeof window === "undefined") memory.delete(key);
    else window.localStorage.removeItem(key);
  },
};

function bump(kind: BlockKind, status: ChapterStatus): ChapterStatus {
  if ((kind === "learn" || kind === "practice") && status === "not_started") return "learning";
  if (kind === "revise" && status !== "revised") return "revised";
  return status;
}

export const useDesk = create<DeskState>()(
  persist(
    (set) => ({
      confirmed: false,
      stream: "commerce",
      subjectIds: defaultSubjectIds("commerce"),
      chapters: {},
      checks: {},
      mocks: [],
      confirm: (stream, subjectIds) => set({ confirmed: true, stream, subjectIds, checks: {} }),
      reopen: () => set({ confirmed: false }),
      toggleCheck: (block) =>
        set((state) => {
          const on = !state.checks[block.id];
          const checks = { ...state.checks, [block.id]: on };
          if (!on || !block.chapterId) return { checks };
          const prev = state.chapters[block.chapterId] ?? { status: "not_started" as const, difficult: false };
          const status = bump(block.kind, prev.status);
          if (status === prev.status) return { checks };
          return {
            checks,
            chapters: { ...state.chapters, [block.chapterId]: { ...prev, status } },
          };
        }),
      setStatus: (chapterId, status) =>
        set((state) => {
          const prev = state.chapters[chapterId] ?? { status: "not_started" as const, difficult: false };
          return { chapters: { ...state.chapters, [chapterId]: { ...prev, status } } };
        }),
      toggleDifficult: (chapterId) =>
        set((state) => {
          const prev = state.chapters[chapterId] ?? { status: "not_started" as const, difficult: false };
          return {
            chapters: { ...state.chapters, [chapterId]: { ...prev, difficult: !prev.difficult } },
          };
        }),
      addMock: (mock) =>
        set((state) => ({
          mocks: [...state.mocks, { ...mock, id: `${mock.date}-${mock.subjectId}-${state.mocks.length}` }],
        })),
      removeMock: (id) => set((state) => ({ mocks: state.mocks.filter((m) => m.id !== id) })),
      resetProgress: () => set({ chapters: {}, checks: {}, mocks: [] }),
    }),
    {
      name: "desk12-v1",
      skipHydration: true,
      storage: createJSONStorage(() => storage),
    },
  ),
);
