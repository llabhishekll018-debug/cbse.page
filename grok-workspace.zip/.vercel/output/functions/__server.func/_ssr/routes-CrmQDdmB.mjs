import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ChevronRight, c as BookOpen, i as Flame, n as RotateCcw, o as ChevronLeft, r as Printer, s as CalendarDays, t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CrmQDdmB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PLAN_START = "2026-11-19";
var DATESHEET = {
	status: "final",
	released: "6 November 2026",
	circular: "CBSE/Date Sheet/X-XII/2026-27",
	window: "16 February 2027 to 9 April 2027",
	startTime: "10:30 am",
	note: "This is the final datesheet, not a tentative one. CBSE released it on 6 November 2026, about 101 days before the first paper. Every theory exam starts at 10:30 am."
};
var SOURCES = [
	{
		label: "CBSE official website",
		href: "https://www.cbse.gov.in/",
		note: "Date sheet notice dated 6 Nov 2026, document CBSE/Date Sheet/X-XII/2026-27."
	},
	{
		label: "Class X and XII date sheet PDF",
		href: "https://www.cbse.gov.in/cbsenew/documents/Datesheet_ClassX%20_XII_2027_Main_06112026.pdf",
		note: "Final timetable. Class XII theory runs 16 Feb–9 Apr 2027."
	},
	{
		label: "Indian Express — stream-wise Class 12 dates",
		href: "https://indianexpress.com/article/education/cbse-class-12th-date-sheet-2027-check-schedule-for-science-humanities-commerce-streams-10955321/",
		note: "Commerce: Accountancy 23 Feb, English 5 Mar, Economics 16 Mar, Business Studies 1 Apr."
	},
	{
		label: "Livemint — subject-wise timetable",
		href: "https://www.livemint.com/education/news/cbse-class-10-12-board-exam-date-sheet-released-subject-wise-timetable-how-to-download-pdf-all-you-need-to-know-11794017564106.html",
		note: "Same major dates, cross-checked with Times of India and Sarvgyan."
	},
	{
		label: "Accountancy syllabus 2026-27 (Delhi DOE)",
		href: "https://edustud.nic.in/edu/Syllabus_2026_27/12/12_Accouints_SYLLABUS_2026_27_EM.pdf",
		note: "Partnership and companies 60 marks, financial statement analysis 20, project 20."
	},
	{
		label: "Business Studies syllabus 2026-27 (Delhi DOE)",
		href: "https://edustud.nic.in/edu/Syllabus_2026_27/12/12_businessstudy_SYLLABUS_2026_27_EM.pdf",
		note: "All 12 units are in, including Business Environment and Financial Markets."
	},
	{
		label: "English Core curriculum file 2026-27",
		href: "https://cbseacademic.nic.in/web_material/CurriculumMain27/SecPart2/English_core_SecP2_2026-27.pdf",
		note: "Linked from the Delhi DOE 2026-27 English specification on cbseacademic.nic.in."
	},
	{
		label: "Economics course structure 2026-27",
		href: "https://new.saralstudy.com/syllabus/cbse/class-12/economics",
		note: "Macro 40 + Indian Economic Development 40 + project 20. Poverty and Infrastructure are not separate units."
	},
	{
		label: "Painting Class XII syllabus 2026-27",
		href: "http://resources.edunexttechnologies.com/web-data/dpshardwar/pdf/PAINTING-CLASS-XII-SYLLABUS-2026-27.pdf",
		note: "Theory 30 marks, 2 hours. Practical 70 is conducted at school, not on this datesheet."
	}
];
function ch(subject, n, name, part, units, focus) {
	return {
		id: `${subject}-${n}`,
		name,
		part,
		units,
		focus
	};
}
var SUBJECTS = [
	{
		id: "acc",
		name: "Accountancy",
		short: "Accountancy",
		code: "055",
		token: "acc",
		streams: ["commerce"],
		defaultOn: ["commerce"],
		examDate: "2027-02-23",
		end: "13:30",
		marks: "80 theory + 20 project",
		paperMarks: 80,
		hardness: 1.4,
		source: "Delhi DOE Accountancy syllabus 2026-27, code 055",
		omitted: ["Accounting for Not-for-Profit Organisations is not in the Class 12 course. Skip it if an old book still has it."],
		chapters: [
			ch("acc", 1, "Fundamentals of Partnership", "Partnership", 3, "Features, deed, Act 1932 rules, interest on capital and drawings, profit division."),
			ch("acc", 2, "Goodwill: Nature and Valuation", "Partnership", 2, "Average profit, super profit, capitalisation. When goodwill is valued."),
			ch("acc", 3, "Change in Profit-Sharing Ratio", "Partnership", 2, "Sacrificing and gaining ratio, goodwill adjustment, reserves."),
			ch("acc", 4, "Admission of a Partner", "Partnership", 4, "New ratio, goodwill treatment, revaluation, capitals, balance sheet."),
			ch("acc", 5, "Retirement of a Partner", "Partnership", 3, "Gaining ratio, goodwill, revaluation, loan account, remaining capitals."),
			ch("acc", 6, "Death of a Partner", "Partnership", 2, "Executor’s account, share of profit till death, similar to retirement."),
			ch("acc", 7, "Dissolution of a Partnership Firm", "Partnership", 3, "Realisation account, partner’s loan, assets taken over, expenses."),
			ch("acc", 8, "Accounting for Share Capital", "Companies", 4, "Issue, forfeiture, reissue, pro-rata, presentation in the balance sheet."),
			ch("acc", 9, "Issue of Debentures", "Companies", 3, "Issue at par, premium, discount, collateral, interest, writing off discount."),
			ch("acc", 10, "Financial Statements of a Company", "Analysis", 2, "Schedule III headings, notes, current and non-current."),
			ch("acc", 11, "Analysis of Financial Statements", "Analysis", 3, "Comparative, common-size, and the main liquidity and solvency ratios."),
			ch("acc", 12, "Cash Flow Statement", "Analysis", 3, "Operating, investing, financing. Indirect method and working-capital changes.")
		]
	},
	{
		id: "paint",
		name: "Painting",
		short: "Painting",
		code: "049",
		token: "paint",
		streams: [
			"commerce",
			"science",
			"humanities"
		],
		defaultOn: ["commerce"],
		examDate: "2027-02-24",
		end: "12:30",
		marks: "30 theory + 70 practical",
		paperMarks: 30,
		hardness: 1.25,
		source: "Painting code 049 syllabus breakup 2026-27",
		omitted: ["The practical (nature study, composition, portfolio, 70 marks) is held at your school, usually before the theory paper. Ask your art teacher for that date. It is not on the theory datesheet."],
		chapters: [
			ch("paint", 1, "Rajasthani School of Miniature Painting", "Miniatures", 2, "Origin, features, sub-schools, and the named paintings in the syllabus."),
			ch("paint", 2, "Pahari School of Miniature Painting", "Miniatures", 2, "Basohli, Guler, Kangra. Features and the set paintings."),
			ch("paint", 3, "Mughal School of Miniature Painting", "Miniatures", 2, "Akbar to Shah Jahan, features, named works and painters."),
			ch("paint", 4, "Deccan Schools of Miniature Painting", "Miniatures", 2, "Ahmednagar, Bijapur, Golconda, Hyderabad. Named plates."),
			ch("paint", 5, "Bengal School and the National Flag", "Modern", 2, "Revival, Abanindranath, flag colours and their meaning."),
			ch("paint", 6, "Modern Trends: Paintings", "Modern", 2, "Named modern paintings: artist, school, medium, what to say in 2 hours."),
			ch("paint", 7, "Modern Trends: Graphic Prints", "Modern", 1, "Printmakers in the syllabus and how a print differs from a painting."),
			ch("paint", 8, "Modern Trends: Sculptures", "Modern", 1, "Named sculptures, medium, and a short appreciation frame."),
			ch("paint", 9, "Nature and Object Study", "Practical", 2, "Light, shade, two or three objects, drapery. Portfolio pages, not theory cram."),
			ch("paint", 10, "Composition and Portfolio", "Practical", 2, "Imagination-based composition plus portfolio selection and mounting.")
		]
	},
	{
		id: "eng",
		name: "English Core",
		short: "English",
		code: "301",
		token: "eng",
		streams: [
			"commerce",
			"science",
			"humanities"
		],
		defaultOn: [
			"commerce",
			"science",
			"humanities"
		],
		examDate: "2027-03-05",
		end: "13:30",
		marks: "80 theory + 20 assessment",
		paperMarks: 80,
		hardness: 1.3,
		source: "English Core 301, Flamingo and Vistas, 2026-27 school course",
		omitted: ["Still out: the poem An Elementary School Classroom in a Slum, and the Vistas stories Should Wizard Hit Mommy and Evans Tries an O-Level.", "Writing that is out: note-making, posters, debate and speech. In: unseen passages, notice, invitation and reply, job letter, letter to the editor, article, report."],
		chapters: [
			ch("eng", 1, "The Last Lesson", "Flamingo prose", 1, "Language, regret, M. Hamel. Short and long answers."),
			ch("eng", 2, "Lost Spring", "Flamingo prose", 2, "Saheb and Mukesh. Poverty, childhood, two-part contrast."),
			ch("eng", 3, "Deep Water", "Flamingo prose", 1, "Fear of water, Roosevelt, how Douglas retrains."),
			ch("eng", 4, "The Rattrap", "Flamingo prose", 2, "Peddler, ironmaster, Edla. Rattrap as metaphor."),
			ch("eng", 5, "Indigo", "Flamingo prose", 2, "Champaran, Gandhi’s method, synthetic indigo, peasant courage."),
			ch("eng", 6, "Poets and Pancakes", "Flamingo prose", 1, "Gemini Studios, humour, office types. Character sketches."),
			ch("eng", 7, "The Interview", "Flamingo prose", 2, "Part I ideas about interviews. Part II Umberto Eco."),
			ch("eng", 8, "Going Places", "Flamingo prose", 1, "Sophie, dreams versus reality, her brother Geoff."),
			ch("eng", 9, "My Mother at Sixty-Six", "Flamingo poetry", 1, "Ageing, the poet’s fear, childhood simile, smile at the end."),
			ch("eng", 10, "Keeping Quiet", "Flamingo poetry", 1, "Neruda, stillness, what the poem is not asking for."),
			ch("eng", 11, "A Thing of Beauty", "Flamingo poetry", 1, "Keats, what beauty does, the examples in the poem."),
			ch("eng", 12, "A Roadside Stand", "Flamingo poetry", 1, "Rural poor, the stand, complaint against the city."),
			ch("eng", 13, "Aunt Jennifer’s Tigers", "Flamingo poetry", 1, "Tigers versus Aunt, wedding band, the message."),
			ch("eng", 14, "The Third Level", "Vistas", 1, "Charley, the third level, escape, Sam’s letter."),
			ch("eng", 15, "The Tiger King", "Vistas", 2, "Satire, prophecy, the hundred tigers, the wooden tiger."),
			ch("eng", 16, "Journey to the End of the Earth", "Vistas", 1, "Antarctica, Students on Ice, why the past matters."),
			ch("eng", 17, "The Enemy", "Vistas", 2, "Dr Sadao, the American soldier, duty versus nation."),
			ch("eng", 18, "On the Face of It", "Vistas", 1, "Derry and Mr Lamb. Scars, garden, the ending."),
			ch("eng", 19, "Memories of Childhood", "Vistas", 2, "Zitkala-Sa and Bama. Two experiences of discrimination."),
			ch("eng", 20, "Unseen passages", "Reading", 2, "Factual and literary passages. Time yourself: about 25 minutes."),
			ch("eng", 21, "Notice, invitation and reply", "Writing", 2, "Format marks first. One of each under a timer."),
			ch("eng", 22, "Letters: job application and editor", "Writing", 2, "Bio-data with the job letter. Editor: issue, causes, request."),
			ch("eng", 23, "Article and report", "Writing", 2, "Heading, byline, tight paragraphs. Report stays factual.")
		]
	},
	{
		id: "eco",
		name: "Economics",
		short: "Economics",
		code: "030",
		token: "eco",
		streams: ["commerce", "humanities"],
		defaultOn: ["commerce", "humanities"],
		examDate: "2027-03-16",
		end: "13:30",
		marks: "80 theory + 20 project",
		paperMarks: 80,
		hardness: 1.35,
		source: "CBSE Economics 030 course structure 2026-27",
		omitted: ["Poverty, and Infrastructure, are not separate units in the current Indian Economic Development course. Do not spend a week on old notes for those."],
		chapters: [
			ch("eco", 1, "National Income and Related Aggregates", "Macro", 4, "Stock and flow, circular flow, value added, income and expenditure methods."),
			ch("eco", 2, "Money and Banking", "Macro", 2, "Functions of money, money supply, central bank, credit creation."),
			ch("eco", 3, "Determination of Income and Employment", "Macro", 4, "AD-AS, consumption function, multiplier, excess demand, deficient demand."),
			ch("eco", 4, "Government Budget and the Economy", "Macro", 2, "Objectives, revenue and capital, deficit types, how they are related."),
			ch("eco", 5, "Balance of Payments", "Macro", 2, "Current and capital account, deficit, foreign exchange, determination of rate."),
			ch("eco", 6, "Indian Economy on the Eve of Independence", "Indian development", 2, "Agriculture, industry, trade, demographics at independence."),
			ch("eco", 7, "Indian Economy 1950–1990", "Indian development", 2, "Goals of planning, land reforms, green revolution, industrial policy."),
			ch("eco", 8, "Liberalisation, Privatisation and Globalisation", "Indian development", 2, "1991 crisis, LPG policies, and an honest appraisal."),
			ch("eco", 9, "Human Capital Formation in India", "Indian development", 2, "Sources, people as a resource, education and health problems."),
			ch("eco", 10, "Rural Development", "Indian development", 2, "Credit, marketing, diversification, organic farming."),
			ch("eco", 11, "Employment", "Indian development", 2, "Formal and informal, unemployment types, jobless growth."),
			ch("eco", 12, "Environment and Sustainable Development", "Indian development", 2, "Functions of environment, degradation, strategies."),
			ch("eco", 13, "India and its Neighbours", "Indian development", 2, "India, China, Pakistan: indicators and what the comparison shows.")
		]
	},
	{
		id: "bst",
		name: "Business Studies",
		short: "Business Studies",
		code: "054",
		token: "bst",
		streams: ["commerce"],
		defaultOn: ["commerce"],
		examDate: "2027-04-01",
		end: "13:30",
		marks: "80 theory + 20 project",
		paperMarks: 80,
		hardness: 1.35,
		source: "Delhi DOE Business Studies syllabus 2026-27, code 054",
		omitted: ["No full chapter is dropped. Older lists that delete Business Environment or Financial Markets are out of date for 2026-27. Demonetisation stays inside Business Environment."],
		chapters: [
			ch("bst", 1, "Nature and Significance of Management", "Management", 2, "Meaning, objectives, levels, coordination, management as science, art, profession."),
			ch("bst", 2, "Principles of Management", "Management", 3, "Fayol’s 14, Taylor’s principles and techniques. Caselets."),
			ch("bst", 3, "Business Environment", "Management", 2, "Dimensions, importance, demonetisation features. Caselets."),
			ch("bst", 4, "Planning", "Management", 2, "Process, types of plans, limitations. Single-use versus standing."),
			ch("bst", 5, "Organising", "Management", 2, "Structure, delegation versus decentralisation, formal and informal."),
			ch("bst", 6, "Staffing", "Management", 2, "Process, recruitment sources, selection steps, training."),
			ch("bst", 7, "Directing", "Management", 3, "Supervision, motivation theories, Maslow, financial and non-financial incentives, leadership, communication."),
			ch("bst", 8, "Controlling", "Management", 2, "Process, relationship with planning, importance."),
			ch("bst", 9, "Financial Management", "Finance and marketing", 3, "Decisions, capital structure, fixed and working capital factors."),
			ch("bst", 10, "Financial Markets", "Finance and marketing", 3, "Money and capital market, primary and secondary, SEBI, trading procedure."),
			ch("bst", 11, "Marketing Management", "Finance and marketing", 3, "Functions, marketing mix, product, price, place, promotion."),
			ch("bst", 12, "Consumer Protection", "Finance and marketing", 2, "Rights, responsibilities, remedies, Consumer Protection Act.")
		]
	},
	{
		id: "phy",
		name: "Physics",
		short: "Physics",
		code: "042",
		token: "phy",
		streams: ["science"],
		defaultOn: ["science"],
		examDate: "2027-02-16",
		end: "13:30",
		marks: "70 theory + 30 practical",
		paperMarks: 70,
		hardness: 1.4,
		source: "CBSE Physics 042, NCERT Class 12",
		omitted: ["Communication Systems is not a separate unit in the current course."],
		chapters: [
			ch("phy", 1, "Electric Charges and Fields", "Electrostatics", 3, "Coulomb, field, flux, Gauss’s law applications."),
			ch("phy", 2, "Electrostatic Potential and Capacitance", "Electrostatics", 3, "Potential, capacitors in series and parallel, energy."),
			ch("phy", 3, "Current Electricity", "Current", 3, "Ohm, Kirchhoff, Wheatstone, meter bridge, cells."),
			ch("phy", 4, "Moving Charges and Magnetism", "Magnetism", 3, "Biot-Savart, Ampere, force on a wire and a charge, galvanometer."),
			ch("phy", 5, "Magnetism and Matter", "Magnetism", 1, "Dipole, dia, para, ferro. Earth’s magnetism in brief."),
			ch("phy", 6, "Electromagnetic Induction", "Induction", 2, "Faraday, Lenz, motional emf, self and mutual inductance."),
			ch("phy", 7, "Alternating Current", "Induction", 2, "Phasors, LCR, resonance, power, transformer."),
			ch("phy", 8, "Electromagnetic Waves", "Waves", 1, "Spectrum, displacement current, uses of each band."),
			ch("phy", 9, "Ray Optics", "Optics", 3, "Mirrors, lenses, prism, optical instruments, sign convention."),
			ch("phy", 10, "Wave Optics", "Optics", 2, "Huygens, Young’s experiment, diffraction."),
			ch("phy", 11, "Dual Nature of Radiation and Matter", "Modern", 2, "Photoelectric effect graphs, de Broglie."),
			ch("phy", 12, "Atoms", "Modern", 1, "Bohr model, spectra."),
			ch("phy", 13, "Nuclei", "Modern", 2, "Binding energy, radioactivity, fission and fusion."),
			ch("phy", 14, "Semiconductor Electronics", "Modern", 2, "Diode, rectifier, logic gates.")
		]
	},
	{
		id: "chem",
		name: "Chemistry",
		short: "Chemistry",
		code: "043",
		token: "chem",
		streams: ["science"],
		defaultOn: ["science"],
		examDate: "2027-02-27",
		end: "13:30",
		marks: "70 theory + 30 practical",
		paperMarks: 70,
		hardness: 1.35,
		source: "CBSE Chemistry 043, current NCERT",
		omitted: ["Not separate units now: Solid State, Surface Chemistry, Isolation of Elements, the old p-Block block, Polymers, Chemistry in Everyday Life."],
		chapters: [
			ch("chem", 1, "Solutions", "Physical", 3, "Concentration, Raoult, colligative properties, van ’t Hoff factor."),
			ch("chem", 2, "Electrochemistry", "Physical", 3, "Nernst, conductance, cells, Faraday, batteries."),
			ch("chem", 3, "Chemical Kinetics", "Physical", 2, "Order, molecularity, integrated rate laws, Arrhenius."),
			ch("chem", 4, "d- and f-Block Elements", "Inorganic", 2, "Trends, potassium dichromate and permanganate, lanthanoids."),
			ch("chem", 5, "Coordination Compounds", "Inorganic", 3, "Nomenclature, isomerism, VBT, CFT, colours."),
			ch("chem", 6, "Haloalkanes and Haloarenes", "Organic", 2, "Preparation, SN1 and SN2, stereochemistry."),
			ch("chem", 7, "Alcohols, Phenols and Ethers", "Organic", 2, "Preparation, acidity of phenol, named reactions."),
			ch("chem", 8, "Aldehydes, Ketones and Carboxylic Acids", "Organic", 3, "Nucleophilic addition, named reactions, acidity."),
			ch("chem", 9, "Amines", "Organic", 2, "Basicity, diazonium salts, distinction tests."),
			ch("chem", 10, "Biomolecules", "Organic", 2, "Carbohydrates, proteins, vitamins, nucleic acids.")
		]
	},
	{
		id: "math",
		name: "Mathematics",
		short: "Maths",
		code: "041",
		token: "math",
		streams: ["science", "commerce"],
		defaultOn: ["science"],
		examDate: "2027-03-09",
		end: "13:30",
		marks: "80 theory + 20 internal",
		paperMarks: 80,
		hardness: 1.4,
		source: "CBSE Mathematics 041",
		omitted: ["Applied Mathematics (241) is a different paper on the same morning. Do not tick both."],
		chapters: [
			ch("math", 1, "Relations and Functions", "Algebra", 2, "Types of relations and functions, composition, invertible."),
			ch("math", 2, "Inverse Trigonometric Functions", "Algebra", 1, "Domain, range, principal values, properties."),
			ch("math", 3, "Matrices", "Algebra", 2, "Operations, transpose, symmetric, inverse by elementary ops."),
			ch("math", 4, "Determinants", "Algebra", 2, "Properties, area, adjoint, inverse, linear equations."),
			ch("math", 5, "Continuity and Differentiability", "Calculus", 3, "Continuity, derivatives of inverse trig, logarithmic, second order."),
			ch("math", 6, "Applications of Derivatives", "Calculus", 2, "Rate, increasing, maxima and minima."),
			ch("math", 7, "Integrals", "Calculus", 4, "Substitution, partial fractions, by parts, definite properties."),
			ch("math", 8, "Applications of Integrals", "Calculus", 1, "Area under curves."),
			ch("math", 9, "Differential Equations", "Calculus", 2, "Order, degree, variable separable, linear."),
			ch("math", 10, "Vector Algebra", "Vectors", 2, "Dot, cross, projection, collinearity."),
			ch("math", 11, "Three Dimensional Geometry", "Vectors", 2, "Line and plane, shortest distance, angle."),
			ch("math", 12, "Linear Programming", "Applied", 1, "Graphical method, feasible region, corner points."),
			ch("math", 13, "Probability", "Applied", 2, "Conditional, Bayes, random variable and distribution in the course.")
		]
	},
	{
		id: "amth",
		name: "Applied Mathematics",
		short: "Applied Maths",
		code: "241",
		token: "amth",
		streams: ["commerce"],
		defaultOn: [],
		examDate: "2027-03-09",
		end: "13:30",
		marks: "80 theory + 20 internal",
		paperMarks: 80,
		hardness: 1.3,
		source: "CBSE Applied Mathematics 241",
		omitted: ["Same morning as Mathematics 041. Tick only the paper you actually sit."],
		chapters: [
			ch("amth", 1, "Numbers, Quantification and Numerical Applications", "Core", 2, "Modulo, allegation, boats and streams, pipes, races."),
			ch("amth", 2, "Algebra", "Core", 3, "Matrices, determinants, and applications in the course."),
			ch("amth", 3, "Calculus", "Core", 4, "Differentiation, applications, integration, differential equations."),
			ch("amth", 4, "Probability Distributions", "Stats", 2, "Random variable, binomial and other distributions in the book."),
			ch("amth", 5, "Inferential Statistics", "Stats", 2, "Sampling, hypothesis testing as in the textbook."),
			ch("amth", 6, "Index Numbers and Time Series", "Finance", 2, "Index construction, trend, seasonal variation."),
			ch("amth", 7, "Financial Mathematics", "Finance", 3, "Interest, annuity, depreciation, EMI, CAGR."),
			ch("amth", 8, "Linear Programming", "Applied", 2, "Formulation and graphical solution.")
		]
	},
	{
		id: "bio",
		name: "Biology",
		short: "Biology",
		code: "044",
		token: "bio",
		streams: ["science"],
		defaultOn: [],
		examDate: "2027-03-25",
		end: "13:30",
		marks: "70 theory + 30 practical",
		paperMarks: 70,
		hardness: 1.25,
		source: "CBSE Biology 044, NCERT",
		omitted: ["Reproduction units are in the course. Strategies for Enhancement in Food Production is not a separate unit."],
		chapters: [
			ch("bio", 1, "Sexual Reproduction in Flowering Plants", "Reproduction", 2, "Flower, pollen, pistil, double fertilisation, seed."),
			ch("bio", 2, "Human Reproduction", "Reproduction", 2, "Systems, gametogenesis, menstrual cycle, pregnancy."),
			ch("bio", 3, "Reproductive Health", "Reproduction", 1, "Problems, contraception, ART, MTP."),
			ch("bio", 4, "Principles of Inheritance and Variation", "Genetics", 3, "Mendel, deviations, sex linkage, disorders, pedigree."),
			ch("bio", 5, "Molecular Basis of Inheritance", "Genetics", 3, "DNA, replication, transcription, translation, lac operon, genome."),
			ch("bio", 6, "Evolution", "Genetics", 2, "Origin, Hardy-Weinberg, evidences, human evolution."),
			ch("bio", 7, "Human Health and Disease", "Biology in welfare", 2, "Immunity, AIDS, cancer, drugs, adolescence."),
			ch("bio", 8, "Microbes in Human Welfare", "Biology in welfare", 1, "Household, industrial, sewage, biocontrol."),
			ch("bio", 9, "Biotechnology: Principles and Processes", "Biotech", 2, "Tools, PCR, process of recombinant DNA."),
			ch("bio", 10, "Biotechnology and its Applications", "Biotech", 1, "Bt crops, insulin, gene therapy, ethics."),
			ch("bio", 11, "Organisms and Populations", "Ecology", 2, "Adaptations, populations, interactions."),
			ch("bio", 12, "Ecosystem", "Ecology", 1, "Structure, productivity, decomposition, nutrient cycles."),
			ch("bio", 13, "Biodiversity and Conservation", "Ecology", 1, "Patterns, loss, in-situ and ex-situ.")
		]
	},
	{
		id: "cs",
		name: "Computer Science",
		short: "Computer Science",
		code: "083",
		token: "cs",
		streams: ["science", "commerce"],
		defaultOn: [],
		examDate: "2027-03-31",
		end: "13:30",
		marks: "70 theory + 30 practical",
		paperMarks: 70,
		hardness: 1.15,
		source: "CBSE Computer Science 083. Informatics Practices is the same morning.",
		omitted: ["Informatics Practices (065) is the same day. Tick only the one you sit."],
		chapters: [
			ch("cs", 1, "Exception Handling in Python", "Python", 1, "try, except, else, finally, raise."),
			ch("cs", 2, "File Handling", "Python", 2, "Text and binary files, open modes, CSV if in your book."),
			ch("cs", 3, "Stack", "Data structures", 2, "Implementation with list, applications, infix to postfix if in course."),
			ch("cs", 4, "Queue", "Data structures", 1, "Linear queue with list, applications."),
			ch("cs", 5, "Computer Networks", "Networks", 2, "Types, devices, topologies, protocols, web, security basics."),
			ch("cs", 6, "Database Concepts", "SQL", 1, "Keys, relations, degree, cardinality."),
			ch("cs", 7, "Structured Query Language", "SQL", 3, "DDL, DML, select, functions, joins, group by."),
			ch("cs", 8, "Interface of Python with SQL", "SQL", 2, "Connecting, cursor, execute, fetch, commit.")
		]
	},
	{
		id: "pe",
		name: "Physical Education",
		short: "Physical Education",
		code: "048",
		token: "pe",
		streams: [
			"commerce",
			"science",
			"humanities"
		],
		defaultOn: [],
		examDate: "2027-02-18",
		end: "13:30",
		marks: "70 theory + 30 practical",
		paperMarks: 70,
		hardness: .9,
		source: "CBSE Physical Education 048",
		omitted: ["Practical is at school, before the theory date."],
		chapters: [
			ch("pe", 1, "Management of Sporting Events", "Unit 1", 1, "Functions, tournaments, fixtures, committees."),
			ch("pe", 2, "Children and Women in Sports", "Unit 2", 1, "Motor development, exercise guidelines, female athlete triad."),
			ch("pe", 3, "Yoga as Preventive Measure", "Unit 3", 1, "Asanas for the lifestyle diseases named in the book."),
			ch("pe", 4, "Physical Education and Sports for CWSN", "Unit 4", 1, "Disability types, inclusion strategies."),
			ch("pe", 5, "Sports and Nutrition", "Unit 5", 1, "Balanced diet, nutritive and non-nutritive components, eating disorders."),
			ch("pe", 6, "Test and Measurement", "Unit 6", 1, "Fitness tests, SAI or the tests in your edition."),
			ch("pe", 7, "Physiology and Injuries in Sports", "Unit 7", 1, "Bone and muscle, sports injuries, first aid."),
			ch("pe", 8, "Biomechanics and Sports", "Unit 8", 1, "Newton’s laws, levers, equilibrium, centre of gravity."),
			ch("pe", 9, "Psychology and Sports", "Unit 9", 1, "Personality, aggression, psychological attributes."),
			ch("pe", 10, "Training in Sports", "Unit 10", 1, "Talent, principles of training, types of exercises.")
		]
	},
	{
		id: "ent",
		name: "Entrepreneurship",
		short: "Entrepreneurship",
		code: "066",
		token: "ent",
		streams: ["commerce"],
		defaultOn: [],
		examDate: "2027-02-19",
		end: "13:30",
		marks: "70 theory + 30 practical",
		paperMarks: 70,
		hardness: 1,
		source: "CBSE Entrepreneurship 066",
		omitted: [],
		chapters: [
			ch("ent", 1, "Entrepreneurial Opportunity", "Unit 1", 2, "Sensing opportunities, environment, problem identification."),
			ch("ent", 2, "Enterprise Planning", "Unit 2", 2, "Business plan components."),
			ch("ent", 3, "Enterprise Marketing", "Unit 3", 2, "Marketing mix for a new firm, branding, promotion."),
			ch("ent", 4, "Enterprise Growth Strategies", "Unit 4", 2, "Franchising, mergers, value addition."),
			ch("ent", 5, "Business Arithmetic", "Unit 5", 2, "Unit of sale, unit cost, break-even, EOQ, working capital."),
			ch("ent", 6, "Resource Mobilisation", "Unit 6", 2, "Capital markets, angel investors, venture capital.")
		]
	},
	{
		id: "hin",
		name: "Hindi Core",
		short: "Hindi",
		code: "302",
		token: "hin",
		streams: [
			"commerce",
			"science",
			"humanities"
		],
		defaultOn: [],
		examDate: "2027-03-13",
		end: "13:30",
		marks: "80 theory + 20 assessment",
		paperMarks: 80,
		hardness: 1.1,
		source: "CBSE Hindi Core 302, Aroh and Vitan",
		omitted: ["Five texts are out for 2026-27, including Diary ke Panne. Match this list to your Aroh and Vitan copies before you start."],
		chapters: [
			ch("hin", 1, "आत्मपरिचय, एक गीत — बच्चन", "काव्य", 1, "भाव और काव्य-सौंदर्य। लघु उत्तर तैयार रखें।"),
			ch("hin", 2, "पतंग — आलोक धन्वा", "काव्य", 1, "बच्चों की दुनिया और भाषा।"),
			ch("hin", 3, "कविता के बहाने, बात सीधी थी पर — कुँवर नारायण", "काव्य", 1, "दोनों कविताओं का केंद्रीय भाव।"),
			ch("hin", 4, "कैमरे में बंद अपाहिज — रघुवीर सहाय", "काव्य", 1, "मीडिया पर व्यंग्य।"),
			ch("hin", 5, "उषा — शमशेर", "काव्य", 1, "बिम्ब और भाषा।"),
			ch("hin", 6, "सहर्ष स्वीकारा है — मुक्तिबोध", "काव्य", 1, "स्वीकार और संघर्ष।"),
			ch("hin", 7, "बादल राग — निराला", "काव्य", 1, "क्रांति का रूपक।"),
			ch("hin", 8, "कवितावली — तुलसीदास", "काव्य", 1, "संदर्भ सहित व्याख्या।"),
			ch("hin", 9, "रुबाइयाँ — फ़िराक", "काव्य", 1, "रूपक और संदेश।"),
			ch("hin", 10, "छोटा मेरा खेत — उमाशंकर जोशी", "काव्य", 1, "रचना-प्रक्रिया का रूपक।"),
			ch("hin", 11, "नमक — सज्जाद ज़हीर", "गद्य", 1, "पात्र और संदेश।"),
			ch("hin", 12, "शिरीष के फूल — हजारी प्रसाद द्विवेदी", "गद्य", 1, "ललित निबंध की शैली।"),
			ch("hin", 13, "श्रम विभाजन और जाति-प्रथा — आंबेडकर", "गद्य", 2, "तर्क और उदाहरण। लंबे उत्तर।"),
			ch("hin", 14, "सिल्वर वैडिंग — मनोहर श्याम जोशी", "वितान", 1, "लगभग 60 शब्दों के उत्तर।"),
			ch("hin", 15, "जूझ — आनंद यादव", "वितान", 1, "संघर्ष और शिक्षा।"),
			ch("hin", 16, "अपठित बोध और अभिव्यक्ति", "लेखन", 2, "गद्यांश, काव्यांश, और लेखन प्रारूप।")
		]
	},
	{
		id: "hist",
		name: "History",
		short: "History",
		code: "027",
		token: "hist",
		streams: ["humanities"],
		defaultOn: ["humanities"],
		examDate: "2027-03-27",
		end: "13:30",
		marks: "80 theory + 20 project",
		paperMarks: 80,
		hardness: 1.3,
		source: "CBSE History 027, Themes in Indian History",
		omitted: ["Map work is inside the theory paper. Keep a separate map evening once a week during your History gap."],
		chapters: [
			ch("hist", 1, "Bricks, Beads and Bones", "Book 1", 2, "Harappan urbanism, subsistence, decline."),
			ch("hist", 2, "Kings, Farmers and Towns", "Book 1", 2, "Mahajanapadas, Magadha, inscriptions."),
			ch("hist", 3, "Kinship, Caste and Class", "Book 1", 2, "Mahabharata as a source, social differences."),
			ch("hist", 4, "Thinkers, Beliefs and Buildings", "Book 1", 2, "Buddhism, Jainism, stupas."),
			ch("hist", 5, "Through the Eyes of Travellers", "Book 2", 1, "Al-Biruni, Ibn Battuta, Francois Bernier."),
			ch("hist", 6, "Bhakti-Sufi Traditions", "Book 2", 2, "Traditions, poems, and how historians read them."),
			ch("hist", 7, "An Imperial Capital: Vijayanagara", "Book 2", 2, "City, water, temples, the account of its fall."),
			ch("hist", 8, "Peasants, Zamindars and the State", "Book 2", 2, "Agrarian society under the Mughals, Ain-i-Akbari."),
			ch("hist", 9, "Colonialism and the Countryside", "Book 3", 2, "Bengal revenue, Santhals, Deccan riots."),
			ch("hist", 10, "Rebels and the Raj", "Book 3", 2, "1857, rumours, leaders, how it was represented."),
			ch("hist", 11, "Mahatma Gandhi and the Nationalist Movement", "Book 3", 2, "Non-cooperation, Civil Disobedience, sources."),
			ch("hist", 12, "Framing the Constitution", "Book 3", 2, "Debates in the Constituent Assembly.")
		]
	},
	{
		id: "pol",
		name: "Political Science",
		short: "Political Science",
		code: "028",
		token: "pol",
		streams: ["humanities"],
		defaultOn: ["humanities"],
		examDate: "2027-03-19",
		end: "13:30",
		marks: "80 theory + 20 project",
		paperMarks: 80,
		hardness: 1.25,
		source: "CBSE Political Science 028",
		omitted: [],
		chapters: [
			ch("pol", 1, "Challenges of Nation-Building", "Indian politics", 1, "Partition, integration of states, reorganisation."),
			ch("pol", 2, "Era of One-Party Dominance", "Indian politics", 1, "Congress system, opposition parties."),
			ch("pol", 3, "Politics of Planned Development", "Indian politics", 1, "Planning, mixed economy, the food crisis."),
			ch("pol", 4, "India’s External Relations", "Indian politics", 1, "Non-alignment, neighbours, wars."),
			ch("pol", 5, "Challenges to and Restoration of the Congress System", "Indian politics", 1, "1967, Indira Gandhi, the split."),
			ch("pol", 6, "The Crisis of Democratic Order", "Indian politics", 2, "Emergency, consequences, lessons."),
			ch("pol", 7, "Regional Aspirations", "Indian politics", 2, "Punjab, North-East, Jammu and Kashmir, accommodation."),
			ch("pol", 8, "Recent Developments in Indian Politics", "Indian politics", 1, "Mandal, Mandir, coalition era."),
			ch("pol", 9, "The End of Bipolarity", "World politics", 1, "Soviet collapse, shock therapy, consequences."),
			ch("pol", 10, "Contemporary Centres of Power", "World politics", 1, "EU, ASEAN, China, rising powers."),
			ch("pol", 11, "Contemporary South Asia", "World politics", 1, "Democracy, conflicts, SAARC."),
			ch("pol", 12, "International Organisations", "World politics", 1, "UN, reform, agencies."),
			ch("pol", 13, "Security in the Contemporary World", "World politics", 1, "Traditional and non-traditional threats."),
			ch("pol", 14, "Environment and Natural Resources", "World politics", 1, "Global commons, indigenous peoples, India’s stand."),
			ch("pol", 15, "Globalisation", "World politics", 1, "Causes, political and cultural effects, resistance.")
		]
	},
	{
		id: "geo",
		name: "Geography",
		short: "Geography",
		code: "029",
		token: "geo",
		streams: ["humanities"],
		defaultOn: ["humanities"],
		examDate: "2027-02-25",
		end: "13:30",
		marks: "70 theory + 30 practical",
		paperMarks: 70,
		hardness: 1.2,
		source: "CBSE Geography 029",
		omitted: ["Practical and map file are school-assessed. Keep one map hour inside Human Geography weeks."],
		chapters: [
			ch("geo", 1, "Human Geography: Nature and Scope", "Fundamentals", 1, "Definition, approaches, nature."),
			ch("geo", 2, "The World Population", "Fundamentals", 2, "Distribution, density, growth, migration."),
			ch("geo", 3, "Human Development", "Fundamentals", 1, "Pillars, approaches, international comparisons."),
			ch("geo", 4, "Primary Activities", "Fundamentals", 1, "Gathering, pastoral, agriculture types."),
			ch("geo", 5, "Secondary Activities", "Fundamentals", 1, "Manufacturing, industries, footloose."),
			ch("geo", 6, "Tertiary and Quaternary Activities", "Fundamentals", 1, "Trade, transport services, knowledge economy."),
			ch("geo", 7, "Transport and Communication", "Fundamentals", 1, "Modes, networks, satellites."),
			ch("geo", 8, "International Trade", "Fundamentals", 1, "Bases, WTO, regional trade."),
			ch("geo", 9, "Population: Distribution, Density, Growth (India)", "India", 1, "Distribution, census trends."),
			ch("geo", 10, "Human Settlements", "India", 1, "Rural and urban, types."),
			ch("geo", 11, "Land Resources and Agriculture", "India", 2, "Land use, cropping patterns, problems."),
			ch("geo", 12, "Water Resources", "India", 1, "Scarcity, conservation, watershed."),
			ch("geo", 13, "Mineral and Energy Resources", "India", 1, "Distribution of minerals and conventional and non-conventional energy."),
			ch("geo", 14, "Manufacturing Industries", "India", 1, "Types, location, major industries."),
			ch("geo", 15, "Planning and Sustainable Development", "India", 1, "Planning regions, Indira Gandhi Canal, sustainable development."),
			ch("geo", 16, "Transport and Communication (India)", "India", 1, "Roads, railways, waterways, airways."),
			ch("geo", 17, "International Trade (India)", "India", 1, "Changing composition and direction."),
			ch("geo", 18, "Geographical Perspective on Selected Issues", "India", 1, "Pollution, urban waste, rural-urban migration problems.")
		]
	},
	{
		id: "psy",
		name: "Psychology",
		short: "Psychology",
		code: "037",
		token: "psy",
		streams: ["humanities"],
		defaultOn: [],
		examDate: "2027-03-02",
		end: "13:30",
		marks: "70 theory + 30 practical",
		paperMarks: 70,
		hardness: 1.15,
		source: "CBSE Psychology 037",
		omitted: ["Practical file is assessed at school."],
		chapters: [
			ch("psy", 1, "Variations in Psychological Attributes", "Unit 1", 2, "Intelligence theories, assessment, creativity, aptitude."),
			ch("psy", 2, "Self and Personality", "Unit 2", 2, "Self, personality approaches, assessment."),
			ch("psy", 3, "Meeting Life Challenges", "Unit 3", 2, "Stress, coping, life skills, health."),
			ch("psy", 4, "Psychological Disorders", "Unit 4", 2, "Concepts of abnormality, major disorder categories in the book."),
			ch("psy", 5, "Therapeutic Approaches", "Unit 5", 2, "Psychodynamic, behaviour, cognitive, humanistic, biomedical."),
			ch("psy", 6, "Attitude and Social Cognition", "Unit 6", 2, "Attitude formation and change, schemas, prejudice."),
			ch("psy", 7, "Social Influence and Group Processes", "Unit 7", 2, "Conformity, compliance, obedience, groups, conflict.")
		]
	}
];
var SUBJECT_MAP = Object.fromEntries(SUBJECTS.map((s) => [s.id, s]));
function defaultSubjectIds(stream) {
	return SUBJECTS.filter((s) => s.defaultOn.includes(stream)).map((s) => s.id);
}
function subjectsFromIds(ids) {
	return ids.map((id) => SUBJECT_MAP[id]).filter((s) => Boolean(s)).sort((a, b) => a.examDate.localeCompare(b.examDate) || a.name.localeCompare(b.name));
}
var WEEKDAYS = [
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday"
];
var MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
function parseISODate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y, m - 1, d);
}
function isoFromDate(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function addDays(iso, n) {
	const d = parseISODate(iso);
	d.setDate(d.getDate() + n);
	return isoFromDate(d);
}
function daysBetween(a, b) {
	return Math.round((parseISODate(b).getTime() - parseISODate(a).getTime()) / 864e5);
}
function formatDay(iso) {
	const d = parseISODate(iso);
	return `${WEEKDAYS[d.getDay()].slice(0, 3)}, ${d.getDate()} ${MONTHS[d.getMonth()]}`;
}
function formatFull(iso) {
	const d = parseISODate(iso);
	return `${WEEKDAYS[d.getDay()]}, ${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}
function range(start, end) {
	if (start > end) return [];
	const out = [];
	let cur = start;
	while (cur <= end) {
		out.push(cur);
		cur = addDays(cur, 1);
	}
	return out;
}
function isSun(iso) {
	return parseISODate(iso).getDay() === 0;
}
function isSat(iso) {
	return parseISODate(iso).getDay() === 6;
}
var SLEEP = "Sleep 10:30 pm to 6:30 am (8 hours).";
function brk(start, end, long = false) {
	return {
		start,
		end,
		fixed: {
			kind: "break",
			title: long ? "Long break" : "Break",
			detail: long ? "Snack, water, 25 minutes away from the desk." : "Stand, sip water, ten minutes off the page."
		}
	};
}
function weekdayItems(mode) {
	const main = mode === "learn" ? "learn" : mode === "revise" ? "revise" : "mock";
	const mid = mode === "learn" ? "practice" : mode === "mock" ? "revise" : "mock";
	const late = mode === "learn" ? "revise" : "revise";
	return [
		{
			start: "7:00",
			end: "7:50",
			slot: main
		},
		brk("7:50", "8:00"),
		{
			start: "8:00",
			end: "8:50",
			slot: main
		},
		brk("8:50", "9:00"),
		{
			start: "9:00",
			end: "9:50",
			slot: main
		},
		brk("9:50", "10:00"),
		{
			start: "10:00",
			end: "10:50",
			slot: main
		},
		brk("10:50", "11:15", true),
		{
			start: "11:15",
			end: "12:05",
			slot: mode === "mock" ? "revise" : main
		},
		brk("12:05", "12:15"),
		{
			start: "12:15",
			end: "13:05",
			slot: mid
		},
		{
			start: "13:05",
			end: "14:00",
			fixed: {
				kind: "meal",
				title: "Lunch",
				detail: "Eat away from the desk. No screens if you can help it."
			}
		},
		{
			start: "14:00",
			end: "14:50",
			slot: late
		},
		brk("14:50", "15:00"),
		{
			start: "15:00",
			end: "15:50",
			slot: mode === "learn" ? "learn" : "revise"
		},
		brk("15:50", "16:00"),
		{
			start: "16:00",
			end: "16:50",
			slot: mode === "learn" ? "learn" : "revise"
		},
		{
			start: "16:50",
			end: "17:30",
			fixed: {
				kind: "rest",
				title: "Walk",
				detail: "Twenty to thirty minutes outside or around the house."
			}
		},
		{
			start: "17:30",
			end: "18:00",
			slot: "recap"
		}
	];
}
function saturdayItems(mode) {
	const slot = mode === "learn" ? "learn" : mode === "mock" ? "mock" : "revise";
	return [
		{
			start: "8:00",
			end: "8:50",
			slot
		},
		brk("8:50", "9:00"),
		{
			start: "9:00",
			end: "9:50",
			slot
		},
		brk("9:50", "10:00"),
		{
			start: "10:00",
			end: "10:50",
			slot
		},
		brk("10:50", "11:15", true),
		{
			start: "11:15",
			end: "12:05",
			slot: mode === "learn" ? "practice" : "revise"
		},
		brk("12:05", "12:15"),
		{
			start: "12:15",
			end: "13:05",
			slot: "revise"
		},
		{
			start: "13:05",
			end: "18:00",
			fixed: {
				kind: "rest",
				title: "Afternoon off",
				detail: "Lighter catch-up day. Stop after lunch unless a chapter is still untouched."
			}
		}
	];
}
function sundayItems() {
	return [
		{
			start: "7:00",
			end: "10:00",
			slot: "pyq"
		},
		brk("10:00", "10:20", true),
		{
			start: "10:20",
			end: "11:10",
			slot: "revise"
		},
		brk("11:10", "11:20"),
		{
			start: "11:20",
			end: "12:10",
			slot: "revise"
		},
		{
			start: "12:10",
			end: "13:40",
			fixed: {
				kind: "meal",
				title: "Lunch",
				detail: "Longer lunch after the paper. Eat, then a short walk."
			}
		},
		{
			start: "14:00",
			end: "14:50",
			slot: "revise"
		},
		brk("14:50", "15:00"),
		{
			start: "15:00",
			end: "15:50",
			slot: "revise"
		},
		brk("15:50", "16:00"),
		{
			start: "16:00",
			end: "16:50",
			slot: "practice"
		},
		{
			start: "17:30",
			end: "18:00",
			slot: "recap"
		}
	];
}
function revisionItems(sunday) {
	if (sunday) return [
		{
			start: "7:00",
			end: "10:00",
			slot: "pyq"
		},
		brk("10:00", "10:20", true),
		{
			start: "10:20",
			end: "11:10",
			slot: "revise"
		},
		brk("11:10", "11:20"),
		{
			start: "11:20",
			end: "12:10",
			slot: "revise"
		},
		{
			start: "12:10",
			end: "13:30",
			fixed: {
				kind: "meal",
				title: "Lunch",
				detail: "Keep it light. This is the last full day before the paper."
			}
		},
		{
			start: "13:30",
			end: "14:20",
			slot: "revise"
		},
		brk("14:20", "14:30"),
		{
			start: "14:30",
			end: "15:20",
			slot: "revise"
		},
		brk("15:20", "15:30"),
		{
			start: "15:30",
			end: "16:20",
			slot: "mock"
		},
		{
			start: "16:20",
			end: "17:00",
			fixed: {
				kind: "rest",
				title: "Stop",
				detail: "Pack your bag. No new chapter after this."
			}
		}
	];
	return [
		{
			start: "7:00",
			end: "7:50",
			slot: "revise"
		},
		brk("7:50", "8:00"),
		{
			start: "8:00",
			end: "8:50",
			slot: "revise"
		},
		brk("8:50", "9:00"),
		{
			start: "9:00",
			end: "9:50",
			slot: "revise"
		},
		brk("9:50", "10:00"),
		{
			start: "10:00",
			end: "10:50",
			slot: "revise"
		},
		brk("10:50", "11:15", true),
		{
			start: "11:15",
			end: "12:05",
			slot: "revise"
		},
		brk("12:05", "12:15"),
		{
			start: "12:15",
			end: "13:05",
			slot: "revise"
		},
		{
			start: "13:05",
			end: "14:00",
			fixed: {
				kind: "meal",
				title: "Lunch",
				detail: "Light meal. You still have a formula pass after lunch."
			}
		},
		{
			start: "14:00",
			end: "14:50",
			slot: "revise"
		},
		brk("14:50", "15:00"),
		{
			start: "15:00",
			end: "15:50",
			slot: "revise"
		},
		brk("15:50", "16:00"),
		{
			start: "16:00",
			end: "16:50",
			slot: "mock"
		},
		{
			start: "16:50",
			end: "18:00",
			fixed: {
				kind: "rest",
				title: "Stop",
				detail: "Bag ready. Sleep on time. No fresh chapter tonight."
			}
		}
	];
}
function unitsLeft(queues, id) {
	return (queues[id] ?? []).reduce((sum, c) => sum + c.left, 0);
}
function takeChapter(queues, id) {
	const item = (queues[id] ?? []).find((c) => c.left > 0);
	if (!item) return null;
	item.left -= 1;
	return item.id;
}
function generatePlan(subjectIds) {
	const subjects = subjectsFromIds(subjectIds);
	if (subjects.length === 0) return [];
	const byId = new Map(subjects.map((s) => [s.id, s]));
	const allowedIds = subjects.map((s) => s.id);
	const examDates = new Set(subjects.map((s) => s.examDate));
	const firstExam = subjects[0].examDate;
	const lastExam = subjects[subjects.length - 1].examDate;
	const revisionOf = /* @__PURE__ */ new Map();
	const takenRev = /* @__PURE__ */ new Set();
	for (const s of subjects) {
		let d = addDays(s.examDate, -1);
		while (d >= "2026-11-19" && (examDates.has(d) || takenRev.has(d))) d = addDays(d, -1);
		if (d >= "2026-11-19") {
			takenRev.add(d);
			revisionOf.set(s.id, d);
		}
	}
	const sharedDates = range(PLAN_START, addDays(firstExam, -1)).filter((d) => !examDates.has(d) && !takenRev.has(d));
	const n = sharedDates.length;
	const nLearn = Math.round(n * .55);
	const nRev = Math.round(n * .25);
	const sharedPhase = /* @__PURE__ */ new Map();
	sharedDates.forEach((d, i) => {
		if (i < nLearn) sharedPhase.set(d, "learn");
		else if (i < nLearn + nRev) sharedPhase.set(d, "revise");
		else sharedPhase.set(d, "mock");
	});
	const roles = /* @__PURE__ */ new Map();
	for (const d of range(PLAN_START, lastExam)) {
		const exam = subjects.find((s) => s.examDate === d);
		if (exam) {
			roles.set(d, {
				type: "exam",
				subjectId: exam.id
			});
			continue;
		}
		const rev = subjects.find((s) => revisionOf.get(s.id) === d);
		if (rev) {
			roles.set(d, {
				type: "revision",
				subjectId: rev.id
			});
			continue;
		}
		if (d < firstExam) {
			roles.set(d, {
				type: "shared",
				phase: sharedPhase.get(d) ?? "mock"
			});
			continue;
		}
		const next = subjects.find((s) => s.examDate > d);
		if (next) roles.set(d, {
			type: "gap",
			subjectId: next.id
		});
	}
	const queues = {};
	const chapterOf = /* @__PURE__ */ new Map();
	for (const s of subjects) {
		queues[s.id] = s.chapters.map((c) => ({
			id: c.id,
			left: c.units
		}));
		for (const c of s.chapters) chapterOf.set(c.id, c);
	}
	const reviseCursor = {};
	function urgency(id, today) {
		const sub = byId.get(id);
		if (!sub) return 0;
		return sub.hardness / Math.max(1, daysBetween(today, sub.examDate));
	}
	function nextRevise(id) {
		const sub = byId.get(id);
		if (!sub || sub.chapters.length === 0) return void 0;
		const i = reviseCursor[id] ?? 0;
		reviseCursor[id] = i + 1;
		return sub.chapters[i % sub.chapters.length];
	}
	function pickLearn(pool, today, used, cap) {
		let best = null;
		let bestScore = 0;
		for (const id of pool) {
			const left = unitsLeft(queues, id);
			if (left <= 0) continue;
			let score = left * urgency(id, today);
			if ((used[id] ?? 0) >= cap) score *= .12;
			if (score > bestScore) {
				bestScore = score;
				best = id;
			}
		}
		return best;
	}
	function pickRevise(pool, today, used, cap) {
		const ranked = [...pool].sort((a, b) => urgency(b, today) - urgency(a, today));
		return ranked.find((id) => (used[id] ?? 0) < cap) ?? ranked[0];
	}
	let sundayCount = 0;
	const days = [];
	for (const date of range(PLAN_START, lastExam)) {
		const role = roles.get(date);
		if (!role) continue;
		const weekday = WEEKDAYS[parseISODate(date).getDay()];
		if (role.type === "exam") {
			const sub = byId.get(role.subjectId);
			const next = subjects.find((s) => s.examDate > date);
			const blocks = [{
				id: `${date}-prep`,
				start: "7:30",
				end: "10:00",
				title: "Exam morning",
				detail: `Admit card, bottle, pen. Reach early. ${sub.name} starts at 10:30 am. No new topic.`,
				kind: "rest",
				checkable: false
			}, {
				id: `${date}-exam`,
				start: "10:30",
				end: sub.end,
				title: `Board exam · ${sub.name}`,
				detail: `Code ${sub.code}. ${sub.marks}. Tick this when you are back.`,
				kind: "exam",
				subjectId: sub.id,
				checkable: true
			}];
			if (next && daysBetween(date, next.examDate) === 1) {
				const ch1 = nextRevise(next.id);
				const ch2 = nextRevise(next.id);
				blocks.push({
					id: `${date}-g1`,
					start: "16:30",
					end: "17:20",
					title: ch1 ? `Short glance · ${ch1.name}` : `Short glance · ${next.short}`,
					detail: "Only recall. The next paper is tomorrow morning. Do not open a new chapter.",
					kind: "revise",
					subjectId: next.id,
					chapterId: ch1?.id,
					checkable: true
				}, {
					id: `${date}-g2`,
					start: "17:30",
					end: "18:10",
					title: ch2 ? `Formulas and names · ${ch2.name}` : `Formulas · ${next.short}`,
					detail: "One page of points, then stop and sleep.",
					kind: "revise",
					subjectId: next.id,
					chapterId: ch2?.id,
					checkable: true
				});
			} else if (next) blocks.push({
				id: `${date}-rest`,
				start: "16:00",
				end: "18:00",
				title: "Rest",
				detail: `You earned the evening. ${next.short} starts properly tomorrow. Sleep on time.`,
				kind: "rest",
				checkable: false
			});
			days.push({
				date,
				weekday,
				phase: "exam",
				title: `Exam · ${sub.name}`,
				note: `Paper at 10:30 am, ends ${sub.end}. ${SLEEP}`,
				lighter: false,
				focusSubjectId: sub.id,
				blocks
			});
			continue;
		}
		let pool = allowedIds;
		let mode = "learn";
		let phase = "learn";
		let focusId = subjects[0].id;
		let title = "Study";
		let lighter = false;
		let items = [];
		let sundayPaper = null;
		if (role.type === "revision") {
			focusId = role.subjectId;
			pool = [role.subjectId];
			phase = "revision-day";
			mode = "revise";
			reviseCursor[role.subjectId] = 0;
			title = `Revision day · ${byId.get(role.subjectId).name}`;
			lighter = false;
			items = revisionItems(isSun(date));
			if (isSun(date)) sundayPaper = role.subjectId;
		} else if (role.type === "gap") {
			focusId = role.subjectId;
			pool = [role.subjectId];
			phase = "gap";
			const sub = byId.get(role.subjectId);
			const revDate = revisionOf.get(role.subjectId) ?? sub.examDate;
			if (unitsLeft(queues, role.subjectId) > 0) mode = "learn";
			else if (daysBetween(date, revDate) > 4) mode = "revise";
			else mode = "mock";
			title = mode === "learn" ? `Finish learning · ${sub.name}` : mode === "mock" ? `Mocks · ${sub.name}` : `Revise · ${sub.name}`;
		} else {
			phase = role.phase;
			mode = role.phase;
			pool = allowedIds;
			focusId = [...allowedIds].sort((a, b) => urgency(b, date) - urgency(a, date))[0];
			const focus = byId.get(focusId);
			title = role.phase === "learn" ? `Learn · ${focus.short} first` : role.phase === "revise" ? `Second pass · ${focus.short} first` : `Mock phase · ${focus.short} first`;
		}
		if (role.type !== "revision") {
			if (isSun(date)) {
				sundayCount += 1;
				const ranked = [...pool].sort((a, b) => urgency(b, date) - urgency(a, date));
				sundayPaper = sundayCount % 3 === 0 && ranked[1] ? ranked[1] : ranked[0];
				focusId = sundayPaper;
				title = `Sunday paper · ${byId.get(sundayPaper).name}`;
				items = sundayItems();
				lighter = false;
				if (role.type === "shared") phase = role.phase;
			} else if (isSat(date)) {
				lighter = true;
				title = `Catch-up · ${byId.get(focusId).short}`;
				items = saturdayItems(mode);
			} else items = weekdayItems(mode);
		}
		const used = {};
		const cap = pool.length > 1 ? lighter ? 3 : 4 : 99;
		const blocks = items.map((item, index) => {
			const id = `${date}-${index}`;
			if (item.fixed) return {
				id,
				start: item.start,
				end: item.end,
				title: item.fixed.title,
				detail: item.fixed.detail,
				kind: item.fixed.kind,
				checkable: false
			};
			const slot = item.slot ?? "learn";
			if (slot === "recap") return {
				id,
				start: item.start,
				end: item.end,
				title: "Evening recap",
				detail: "Fifteen flashcards from today, then close the books. Lights out 10:30 pm.",
				kind: "recap",
				subjectId: focusId,
				checkable: true
			};
			if (slot === "pyq") {
				const sid = sundayPaper ?? focusId;
				const sub = byId.get(sid);
				return {
					id,
					start: item.start,
					end: item.end,
					title: `Previous year paper · ${sub.name}`,
					detail: "Full paper, timed, no notes. Treat 7:00 am as the invigilator saying you may start.",
					kind: "pyq",
					subjectId: sid,
					checkable: true
				};
			}
			let sid = focusId;
			let chapterId;
			let kind = slot === "practice" ? "practice" : slot;
			if (slot === "learn" || slot === "practice") {
				if (sundayPaper && slot === "practice") {
					sid = sundayPaper;
					chapterId = nextRevise(sid)?.id;
					kind = "practice";
				} else {
					const picked = pickLearn(pool, date, used, cap);
					if (picked) {
						sid = picked;
						chapterId = takeChapter(queues, picked) ?? void 0;
						used[sid] = (used[sid] ?? 0) + 1;
						kind = slot === "practice" ? "practice" : "learn";
					} else {
						sid = pickRevise(pool, date, used, cap);
						chapterId = nextRevise(sid)?.id;
						used[sid] = (used[sid] ?? 0) + 1;
						kind = "revise";
					}
				}
			} else {
				sid = slot === "mock" || slot === "revise" ? pickRevise(pool, date, used, cap) : focusId;
				if (sundayPaper && (slot === "revise" || slot === "mock")) sid = sundayPaper;
				if (role.type === "revision" || role.type === "gap") sid = role.subjectId;
				if (mode === "learn" && slot === "revise" && !sundayPaper) {
					const top = Object.entries(used).sort((a, b) => b[1] - a[1])[0];
					if (top) sid = top[0];
				}
				chapterId = nextRevise(sid)?.id;
				used[sid] = (used[sid] ?? 0) + 1;
				kind = slot === "mock" ? "mock" : "revise";
			}
			const sub = byId.get(sid);
			const chapter = chapterId ? chapterOf.get(chapterId) : void 0;
			const name = chapter?.name ?? sub.short;
			const focus = chapter?.focus ?? "Use your notes and the marking scheme.";
			let blockTitle = `${sub.short}: ${name}`;
			let detail = focus;
			if (kind === "practice") {
				blockTitle = `Practice · ${name}`;
				detail = `Questions only, then check. ${focus}`;
			} else if (kind === "revise") {
				blockTitle = `Revise · ${name}`;
				detail = `Close the book and recall, then patch holes. ${focus}`;
			} else if (kind === "mock") {
				blockTitle = `Timed section · ${name}`;
				detail = `Exam conditions for this slice. ${focus}`;
			} else {
				blockTitle = `Learn · ${name}`;
				detail = focus;
			}
			if (!focusId) focusId = sid;
			return {
				id,
				start: item.start,
				end: item.end,
				title: blockTitle,
				detail,
				kind,
				subjectId: sid,
				chapterId,
				checkable: true
			};
		});
		const learnedFocus = blocks.find((b) => b.checkable && b.subjectId)?.subjectId ?? focusId;
		days.push({
			date,
			weekday,
			phase,
			title,
			note: lighter ? `Lighter catch-up. Five study blocks, then stop. ${SLEEP}` : phase === "revision-day" ? `Full revision. Nothing new. ${SLEEP}` : `Eight hours in 50-minute blocks, with a 3-hour paper on Sundays. ${SLEEP}`,
			lighter,
			focusSubjectId: learnedFocus,
			blocks
		});
	}
	return days;
}
function backToBack(subjects) {
	const out = [];
	for (let i = 0; i < subjects.length - 1; i++) {
		const freeDays = daysBetween(subjects[i].examDate, subjects[i + 1].examDate) - 1;
		if (freeDays <= 1) out.push({
			a: subjects[i],
			b: subjects[i + 1],
			freeDays
		});
	}
	return out;
}
var memory = /* @__PURE__ */ new Map();
var storage = {
	getItem: (key) => typeof window === "undefined" ? memory.get(key) ?? null : window.localStorage.getItem(key),
	setItem: (key, value) => {
		if (typeof window === "undefined") memory.set(key, value);
		else window.localStorage.setItem(key, value);
	},
	removeItem: (key) => {
		if (typeof window === "undefined") memory.delete(key);
		else window.localStorage.removeItem(key);
	}
};
function bump(kind, status) {
	if ((kind === "learn" || kind === "practice") && status === "not_started") return "learning";
	if (kind === "revise" && status !== "revised") return "revised";
	return status;
}
var useDesk = create()(persist((set) => ({
	confirmed: false,
	stream: "commerce",
	subjectIds: defaultSubjectIds("commerce"),
	chapters: {},
	checks: {},
	mocks: [],
	confirm: (stream, subjectIds) => set({
		confirmed: true,
		stream,
		subjectIds,
		checks: {}
	}),
	reopen: () => set({ confirmed: false }),
	toggleCheck: (block) => set((state) => {
		const on = !state.checks[block.id];
		const checks = {
			...state.checks,
			[block.id]: on
		};
		if (!on || !block.chapterId) return { checks };
		const prev = state.chapters[block.chapterId] ?? {
			status: "not_started",
			difficult: false
		};
		const status = bump(block.kind, prev.status);
		if (status === prev.status) return { checks };
		return {
			checks,
			chapters: {
				...state.chapters,
				[block.chapterId]: {
					...prev,
					status
				}
			}
		};
	}),
	setStatus: (chapterId, status) => set((state) => {
		const prev = state.chapters[chapterId] ?? {
			status: "not_started",
			difficult: false
		};
		return { chapters: {
			...state.chapters,
			[chapterId]: {
				...prev,
				status
			}
		} };
	}),
	toggleDifficult: (chapterId) => set((state) => {
		const prev = state.chapters[chapterId] ?? {
			status: "not_started",
			difficult: false
		};
		return { chapters: {
			...state.chapters,
			[chapterId]: {
				...prev,
				difficult: !prev.difficult
			}
		} };
	}),
	addMock: (mock) => set((state) => ({ mocks: [...state.mocks, {
		...mock,
		id: `${mock.date}-${mock.subjectId}-${state.mocks.length}`
	}] })),
	removeMock: (id) => set((state) => ({ mocks: state.mocks.filter((m) => m.id !== id) })),
	resetProgress: () => set({
		chapters: {},
		checks: {},
		mocks: []
	})
}), {
	name: "desk12-v1",
	skipHydration: true,
	storage: createJSONStorage(() => storage)
}));
var STREAMS = [
	{
		id: "commerce",
		label: "Commerce",
		line: "Accountancy, Business Studies, Economics, English, Painting"
	},
	{
		id: "science",
		label: "Science",
		line: "Physics, Chemistry, Maths, English"
	},
	{
		id: "humanities",
		label: "Humanities",
		line: "History, Political Science, Geography, Economics, English"
	}
];
var STATUS_LABEL = {
	not_started: "Not started",
	learning: "Learning",
	revised: "Revised"
};
function useHydrated() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const unsub = useDesk.persist.onFinishHydration(() => setReady(true));
		useDesk.persist.rehydrate();
		if (useDesk.persist.hasHydrated()) setReady(true);
		return unsub;
	}, []);
	return ready;
}
function useNow() {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(/* @__PURE__ */ new Date());
		tick();
		const id = window.setInterval(tick, 3e4);
		return () => window.clearInterval(id);
	}, []);
	return now;
}
function DeskApp() {
	if (!useHydrated()) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen max-w-3xl flex-col justify-center px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "CBSE Class 12 · 2027 boards"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-serif text-4xl text-fg",
				children: "Desk 12"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-muted",
				children: "Opening your study desk. The datesheet step comes first."
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskReady, {});
}
function DeskReady() {
	if (!useDesk((s) => s.confirmed)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, {});
}
function clashes(ids) {
	const subjects = subjectsFromIds(ids);
	const groups = /* @__PURE__ */ new Map();
	for (const subject of subjects) {
		const list = groups.get(subject.examDate) ?? [];
		list.push(subject.name);
		groups.set(subject.examDate, list);
	}
	return [...groups.values()].filter((names) => names.length > 1).map((names) => names.join(" and "));
}
function ConfirmScreen() {
	const storedStream = useDesk((s) => s.stream);
	const storedIds = useDesk((s) => s.subjectIds);
	const confirm = useDesk((s) => s.confirm);
	const [stream, setStream] = (0, import_react.useState)(storedStream);
	const [ids, setIds] = (0, import_react.useState)(storedIds.length ? storedIds : defaultSubjectIds(storedStream));
	const selected = subjectsFromIds(ids);
	const problems = clashes(ids);
	const core = SUBJECTS.filter((s) => s.streams.includes(stream));
	const extra = SUBJECTS.filter((s) => !s.streams.includes(stream));
	function chooseStream(next) {
		setStream(next);
		setIds(defaultSubjectIds(next));
	}
	function toggle(id) {
		setIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-8 pb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium tracking-wide text-muted uppercase",
				children: "CBSE Class 12 · session 2026-27"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-serif text-4xl text-fg",
				children: "Confirm your subjects"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "The plan is built only after this step. Commerce is selected, with Painting ticked, because that is the set you named. Change anything that is wrong."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-2xl border border-border bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-fg",
						children: "Datesheet status: final"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: DATESHEET.note
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"Window: ",
							DATESHEET.window,
							". Circular ",
							DATESHEET.circular,
							", released ",
							DATESHEET.released,
							". Every paper starts at ",
							DATESHEET.startTime,
							"."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
					className: "text-sm font-medium text-fg",
					children: "Stream"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-2 sm:grid-cols-3",
					children: STREAMS.map((item) => {
						const on = stream === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							"aria-pressed": on,
							onClick: () => chooseStream(item.id),
							className: `min-h-11 rounded-2xl border px-3 py-3 text-left ${on ? "border-fg bg-surface-2" : "border-border bg-surface"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-medium text-fg",
								children: item.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-xs text-muted",
								children: item.line
							})]
						}, item.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubjectGroup, {
				title: "In this stream",
				subjects: core,
				ids,
				onToggle: toggle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubjectGroup, {
				title: "Other papers you might sit",
				subjects: extra,
				ids,
				onToggle: toggle
			}),
			stream === "commerce" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Painting is on because you asked for it. Untick it if you do not sit code 049. It is the day after Accountancy, so the plan finishes Painting before 23 February."
			}),
			problems.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 flex gap-2 rounded-2xl border border-border bg-surface p-3 text-sm text-fg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						className: "mt-0.5 size-4 shrink-0 text-paint",
						"aria-hidden": "true"
					}),
					"Same morning, pick one: ",
					problems.join("; "),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl text-fg",
					children: "Your papers, in order"
				}), selected.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Tick at least one subject."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex flex-col gap-2",
					children: selected.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-2xl border border-border bg-surface px-3 py-3",
						style: { boxShadow: `inset 3px 0 0 var(--color-${subject.token})` },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-medium text-fg",
							children: [
								formatFull(subject.examDate),
								" · ",
								subject.name
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								"Code ",
								subject.code,
								" · 10:30 am to ",
								subject.end === "12:30" ? "12:30 pm" : "1:30 pm",
								" · ",
								subject.marks
							]
						})]
					}, subject.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-fg",
						children: "Chapters in the plan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "These follow the 2026-27 course, not a ten-year-old guide. Lines under a subject are left out on purpose."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-col gap-2",
						children: selected.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "rounded-2xl border border-border bg-surface px-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
									className: "min-h-11 cursor-pointer py-2 font-medium text-fg",
									children: [
										subject.name,
										" · ",
										subject.chapters.length,
										" chapters"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mb-2 flex flex-col gap-1",
									children: subject.chapters.map((chapter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "text-sm text-muted",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-fg",
												children: chapter.name
											}),
											" · ",
											chapter.part
										]
									}, chapter.id))
								}),
								subject.omitted.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-2 text-sm text-muted",
									children: line
								}, line))
							]
						}, subject.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sources, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: ids.length === 0 || problems.length > 0,
				onClick: () => confirm(stream, ids),
				className: "mt-6 min-h-11 rounded-full bg-fg px-5 text-sm font-medium text-bg disabled:opacity-40",
				children: "Build my plan"
			})
		]
	});
}
function SubjectGroup({ title, subjects, ids, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: "mt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
			className: "text-sm font-medium text-fg",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: subjects.map((subject) => {
				const on = ids.includes(subject.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": on,
					onClick: () => onToggle(subject.id),
					className: `min-h-11 rounded-full border px-3 py-2 text-left text-sm ${on ? "border-fg bg-surface-2 text-fg" : "border-border bg-surface text-muted"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 inline-block size-2.5 rounded-full align-middle",
							style: { background: `var(--color-${subject.token})` }
						}),
						subject.short,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 text-xs",
							children: formatDay(subject.examDate)
						})
					]
				}, subject.id);
			})
		})]
	});
}
function Sources() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-2xl text-fg",
			children: "Sources"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 flex flex-col gap-3",
			children: SOURCES.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "font-medium text-fg underline decoration-border underline-offset-4",
					href: source.href,
					target: "_blank",
					rel: "noreferrer",
					children: source.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-muted",
					children: source.note
				})]
			}, source.href))
		})]
	});
}
function completion(subjects, chapters) {
	const all = subjects.flatMap((subject) => subject.chapters);
	if (all.length === 0) return 0;
	const score = all.reduce((sum, chapter) => {
		const status = chapters[chapter.id]?.status ?? "not_started";
		if (status === "revised") return sum + 1;
		if (status === "learning") return sum + .5;
		return sum;
	}, 0);
	return Math.round(score / all.length * 100);
}
function subjectCompletion(subject, chapters) {
	return completion([subject], chapters);
}
function nextUpcoming(subjects, now) {
	const t = now.getTime();
	return subjects.find((subject) => (/* @__PURE__ */ new Date(`${subject.examDate}T${subject.end}:00+05:30`)).getTime() >= t);
}
function streakOf(plan, checks, today) {
	const byDate = new Map(plan.map((day) => [day.date, day]));
	const counted = (iso) => {
		const day = byDate.get(iso);
		if (!day) return false;
		return day.blocks.some((block) => block.checkable && checks[block.id]);
	};
	let cursor = today;
	if (!counted(cursor)) {
		if (cursor <= "2026-11-19") return 0;
		cursor = addDays(cursor, -1);
	}
	let count = 0;
	while (counted(cursor)) {
		count += 1;
		cursor = addDays(cursor, -1);
		if (cursor < "2026-11-19") break;
	}
	return count;
}
function Dashboard() {
	const now = useNow();
	const stream = useDesk((s) => s.stream);
	const subjectIds = useDesk((s) => s.subjectIds);
	const chapters = useDesk((s) => s.chapters);
	const checks = useDesk((s) => s.checks);
	const mocks = useDesk((s) => s.mocks);
	const reopen = useDesk((s) => s.reopen);
	const toggleCheck = useDesk((s) => s.toggleCheck);
	const setStatus = useDesk((s) => s.setStatus);
	const toggleDifficult = useDesk((s) => s.toggleDifficult);
	const addMock = useDesk((s) => s.addMock);
	const removeMock = useDesk((s) => s.removeMock);
	const resetProgress = useDesk((s) => s.resetProgress);
	const subjects = (0, import_react.useMemo)(() => subjectsFromIds(subjectIds), [subjectIds]);
	const plan = (0, import_react.useMemo)(() => generatePlan(subjectIds), [subjectIds]);
	const tight = backToBack(subjects);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [openSubject, setOpenSubject] = (0, import_react.useState)(null);
	const todayISO = now ? isoFromDate(now) : plan[0]?.date ?? "2026-11-19";
	const activeISO = picked ?? todayISO;
	const index = plan.findIndex((day) => day.date === activeISO);
	const safeIndex = index === -1 ? activeISO < (plan[0]?.date ?? activeISO) ? 0 : Math.max(0, plan.length - 1) : index;
	const day = plan[safeIndex];
	const upcoming = now ? nextUpcoming(subjects, now) : subjects[0];
	const days = upcoming && now ? Math.max(0, daysBetween(todayISO, upcoming.examDate)) : 0;
	const percent = completion(subjects, chapters);
	const streak = streakOf(plan, checks, todayISO);
	const focusOpen = openSubject ?? day?.focusSubjectId ?? subjects[0]?.id ?? null;
	const done = day ? day.blocks.filter((block) => block.checkable && checks[block.id]).length : 0;
	const total = day ? day.blocks.filter((block) => block.checkable).length : 0;
	const weak = subjects.flatMap((subject) => subject.chapters.filter((chapter) => chapters[chapter.id]?.difficult).map((chapter) => ({
		subject,
		chapter
	})));
	const hoursLeft = upcoming && now ? examHours(upcoming, now) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "no-print mx-auto max-w-6xl px-4 py-6 pb-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Desk 12 · ",
						streamLabel(stream),
						" · final datesheet"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-4xl text-fg",
					children: "Study desk"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => window.print(),
						className: "inline-flex min-h-11 items-center gap-2 rounded-full bg-fg px-4 text-sm font-medium text-bg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Print my plan"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: reopen,
						className: "min-h-11 rounded-full border border-border px-4 text-sm text-fg",
						children: "Edit subjects"
					})]
				})]
			}),
			tight.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 flex gap-2 rounded-2xl border border-border bg-surface px-3 py-3 text-sm text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "mt-0.5 size-4 shrink-0 text-paint",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tight.map((pair) => pair.freeDays === 0 ? `${pair.b.short} is the day after ${pair.a.short}. There is no full day between them, so ${pair.b.short} is revised before ${pair.a.short}'s paper. The evening of ${formatDay(pair.a.examDate)} is only a short glance.` : `${pair.a.short} and ${pair.b.short} have only one free day between them.`).join(" ") })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, {
							className: "size-4",
							"aria-hidden": "true"
						}),
						label: "Days left",
						value: upcoming ? days === 0 ? "Today" : String(days) : "Done",
						detail: upcoming ? days === 0 && hoursLeft != null ? `${hoursLeft} until ${upcoming.short} starts` : `until ${upcoming.short}` : "Every paper in this set is over"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
							className: "size-4",
							"aria-hidden": "true"
						}),
						label: "Syllabus completed",
						value: `${percent}%`,
						detail: "Revised counts full. Learning counts half."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, {
							className: "size-4",
							"aria-hidden": "true"
						}),
						label: "Next exam",
						value: upcoming ? upcoming.short : "—",
						detail: upcoming ? `${formatFull(upcoming.examDate)} · 10:30 am` : "Nothing left on this datesheet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flame, {
							className: "size-4",
							"aria-hidden": "true"
						}),
						label: "Study streak",
						value: String(streak),
						detail: streak === 1 ? "day with a ticked block" : "days with a ticked block"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium tracking-wide text-muted uppercase",
					children: "Exam timeline"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 flex items-center gap-2 overflow-x-auto pb-2",
					children: subjects.map((subject, i) => {
						const following = subjects[i + 1];
						const free = following ? daysBetween(subject.examDate, following.examDate) - 1 : null;
						const isNext = upcoming?.id === subject.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `min-w-40 rounded-2xl border bg-surface px-3 py-3 ${isNext ? "border-fg" : "border-border"}`,
								style: { boxShadow: `inset 0 -3px 0 var(--color-${subject.token})` },
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: formatDay(subject.examDate)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium text-fg",
										children: subject.short
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: subject.end === "12:30" ? "10:30–12:30" : "10:30–1:30"
									}),
									isNext && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs font-medium text-fg",
										children: "Next"
									})
								]
							}), free != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "max-w-24 text-xs text-muted",
								children: free === 0 ? "Back to back" : `${free} gap day${free === 1 ? "" : "s"}`
							})]
						}, subject.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "lg:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-2xl text-fg",
							children: day && day.date === todayISO ? "Today's plan" : "Day plan"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Previous day",
									disabled: safeIndex <= 0,
									onClick: () => setPicked(plan[safeIndex - 1]?.date ?? null),
									className: "inline-flex size-11 items-center justify-center rounded-full border border-border text-fg disabled:opacity-40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
										className: "size-4",
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setPicked(null),
									className: "min-h-11 rounded-full border border-border px-3 text-sm text-fg",
									children: "Today"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Next day",
									disabled: safeIndex >= plan.length - 1,
									onClick: () => setPicked(plan[safeIndex + 1]?.date ?? null),
									className: "inline-flex size-11 items-center justify-center rounded-full border border-border text-fg disabled:opacity-40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
										className: "size-4",
										"aria-hidden": "true"
									})
								})
							]
						})]
					}), day && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 rounded-2xl border border-border bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: formatFull(day.date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-serif text-2xl text-fg",
								children: day.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: day.note
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-fg",
								children: [
									done,
									" of ",
									total,
									" blocks ticked",
									day.lighter ? " · lighter day" : "",
									" · ",
									phaseLabel(day.phase)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 flex flex-col gap-2",
								children: day.blocks.map((block) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlockRow, {
									block,
									checked: Boolean(checks[block.id]),
									onToggle: () => toggleCheck(block)
								}, block.id))
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-fg",
						children: "Subjects"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: subjects.map((subject) => {
							const pct = subjectCompletion(subject, chapters);
							const learned = subject.chapters.filter((chapter) => (chapters[chapter.id]?.status ?? "not_started") !== "not_started").length;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setOpenSubject(subject.id),
								className: "flex w-full min-h-11 flex-col items-start rounded-2xl border border-border bg-surface p-3 text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ring, {
										token: subject.token,
										pct
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-2 font-medium text-fg",
										children: subject.short
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted",
										children: [
											learned,
											"/",
											subject.chapters.length,
											" started · ",
											formatDay(subject.examDate)
										]
									})
								]
							}) }, subject.id);
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-fg",
						children: "Chapter tracker"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Ticking a learn block moves a chapter to Learning. Ticking a revise block marks it Revised. You can override either."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-col gap-2",
						children: subjects.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "rounded-2xl border border-border bg-surface px-3 py-2",
							open: focusOpen === subject.id,
							onToggle: (event) => {
								if (event.currentTarget.open) setOpenSubject(subject.id);
								else setOpenSubject(focusOpen === subject.id ? "" : focusOpen);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
									className: "flex min-h-11 cursor-pointer items-center justify-between gap-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-medium text-fg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mr-2 inline-block size-2.5 rounded-full",
											style: { background: `var(--color-${subject.token})` }
										}), subject.name]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm text-muted",
										children: [subjectCompletion(subject, chapters), "%"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mb-3 flex flex-col gap-3",
									children: subject.chapters.map((chapter) => {
										const progress = chapters[chapter.id] ?? {
											status: "not_started",
											difficult: false
										};
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "border-t border-border pt-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-medium text-fg",
													children: chapter.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-muted",
													children: chapter.part
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-2 flex flex-wrap gap-2",
													children: [Object.keys(STATUS_LABEL).map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														"aria-pressed": progress.status === status,
														onClick: () => setStatus(chapter.id, status),
														className: `min-h-11 rounded-full border px-3 text-sm ${progress.status === status ? "border-fg bg-surface-2 text-fg" : "border-border text-muted"}`,
														children: STATUS_LABEL[status]
													}, status)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														"aria-pressed": progress.difficult,
														onClick: () => toggleDifficult(chapter.id),
														className: `min-h-11 rounded-full border px-3 text-sm ${progress.difficult ? "border-paint text-fg" : "border-border text-muted"}`,
														children: progress.difficult ? "Difficult" : "Mark difficult"
													})]
												})
											]
										}, chapter.id);
									})
								}),
								subject.omitted.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-3 rounded-xl bg-surface-2 px-3 py-2",
									children: subject.omitted.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: ["Not in this course: ", line]
									}, line))
								})
							]
						}, subject.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-fg",
						children: "Weak topics"
					}), weak.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Nothing marked difficult yet. Use “Mark difficult” on a chapter and it will sit here."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-2",
						children: weak.map(({ subject, chapter }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 rounded-xl bg-surface-2 px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-medium text-fg",
								children: chapter.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: subject.short
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggleDifficult(chapter.id),
								className: "min-h-11 rounded-full border border-border px-3 text-sm text-fg",
								children: "Remove"
							})]
						}, chapter.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MockPanel, {
					subjects,
					mocks,
					today: todayISO,
					addMock,
					removeMock
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: resetProgress,
					className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-border px-4 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
						className: "size-4",
						"aria-hidden": "true"
					}), "Clear ticks and scores"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Saved on this device. Three phases: learn, revise, then mocks. Sundays are a full past paper. Saturdays are the light day."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sources, {})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintSheet, {
		plan,
		subjects,
		stream
	})] });
}
function examHours(subject, now) {
	const diff = (/* @__PURE__ */ new Date(`${subject.examDate}T10:30:00+05:30`)).getTime() - now.getTime();
	if (diff <= 0) return null;
	const hours = Math.floor(diff / 36e5);
	const mins = Math.floor(diff % 36e5 / 6e4);
	if (hours >= 48) return null;
	return `${hours}h ${mins}m`;
}
function streamLabel(stream) {
	if (stream === "science") return "Science";
	if (stream === "humanities") return "Humanities";
	return "Commerce";
}
function phaseLabel(phase) {
	if (phase === "learn") return "Learn phase";
	if (phase === "revise") return "Revise phase";
	if (phase === "mock") return "Mock phase";
	if (phase === "gap") return "Gap days, next paper only";
	if (phase === "revision-day") return "Revision day";
	return "Exam day";
}
function Stat({ icon, label, value, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-2xl border border-border bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-xs font-medium tracking-wide text-muted uppercase",
				children: [icon, label]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-serif text-4xl text-fg",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: detail
			})
		]
	});
}
function Ring({ token, pct }) {
	const r = 15.5;
	const c = 2 * Math.PI * r;
	const dash = Math.max(0, Math.min(100, pct)) / 100 * c;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 36 36",
		className: "size-16",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18",
				cy: "18",
				r,
				fill: "none",
				stroke: "var(--color-border)",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18",
				cy: "18",
				r,
				fill: "none",
				stroke: `var(--color-${token})`,
				strokeWidth: "3",
				strokeLinecap: "round",
				strokeDasharray: `${dash} ${c}`,
				transform: "rotate(-90 18 18)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
				x: "18",
				y: "19",
				textAnchor: "middle",
				dominantBaseline: "middle",
				fill: "var(--color-fg)",
				fontSize: "7",
				fontFamily: "Outfit, sans-serif",
				children: [pct, "%"]
			})
		]
	});
}
function BlockRow({ block, checked, onToggle }) {
	const token = block.subjectId ? SUBJECTS.find((s) => s.id === block.subjectId)?.token ?? "eng" : null;
	if (!block.checkable) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-xl bg-bg px-3 py-2 text-sm text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-xs",
				children: [
					block.start,
					"–",
					block.end
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-fg",
				children: block.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block",
				children: block.detail
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-h-11 cursor-pointer gap-3 rounded-xl bg-surface-2 px-3 py-3",
		style: token ? { boxShadow: `inset 3px 0 0 var(--color-${token})` } : void 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "checkbox",
			checked,
			onChange: onToggle,
			className: "mt-1 size-5 shrink-0 accent-current"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-xs text-muted",
				children: [
					block.start,
					"–",
					block.end,
					checked ? " · done" : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `mt-0.5 block font-medium ${checked ? "text-muted line-through" : "text-fg"}`,
				children: block.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-sm text-muted",
				children: block.detail
			})
		] })]
	}) });
}
function MockPanel({ subjects, mocks, today, addMock, removeMock }) {
	const [subjectId, setSubjectId] = (0, import_react.useState)(subjects[0]?.id ?? "");
	const [score, setScore] = (0, import_react.useState)("");
	const [total, setTotal] = (0, import_react.useState)(String(subjects[0]?.paperMarks ?? 80));
	const [date, setDate] = (0, import_react.useState)(today);
	const [filter, setFilter] = (0, import_react.useState)(subjects[0]?.id ?? "all");
	const rows = mocks.filter((mock) => filter === "all" || mock.subjectId === filter).slice().sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id)).map((mock, i) => ({
		label: `${i + 1}`,
		pct: Math.round(mock.score / mock.total * 100),
		note: `${mock.score}/${mock.total}`
	}));
	function onSubject(id) {
		setSubjectId(id);
		const subject = subjects.find((item) => item.id === id);
		if (subject) setTotal(String(subject.paperMarks));
	}
	function submit(event) {
		event.preventDefault();
		const s = Number(score);
		const t = Number(total);
		if (!subjectId || !Number.isFinite(s) || !Number.isFinite(t) || t <= 0 || s < 0 || s > t) return;
		addMock({
			subjectId,
			score: s,
			total: t,
			date
		});
		setScore("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-2xl text-fg",
				children: "Mock tests"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Log a Sunday paper or any timed test. The line is your percentage."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-3 grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "col-span-2 text-sm text-muted",
						children: ["Subject", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: subjectId,
							onChange: (event) => onSubject(event.target.value),
							className: "mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg",
							children: subjects.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: subject.id,
								children: subject.name
							}, subject.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-muted",
						children: ["Score", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: score,
							onChange: (event) => setScore(event.target.value),
							inputMode: "decimal",
							className: "mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm text-muted",
						children: ["Out of", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: total,
							onChange: (event) => setTotal(event.target.value),
							inputMode: "decimal",
							className: "mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "col-span-2 text-sm text-muted",
						children: ["Date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							value: date,
							onChange: (event) => setDate(event.target.value),
							className: "mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "col-span-2 min-h-11 rounded-full bg-fg text-sm font-medium text-bg",
						children: "Add score"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-sm text-muted",
				children: ["Chart subject", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: filter,
					onChange: (event) => setFilter(event.target.value),
					className: "mt-1 min-h-11 w-full rounded-xl border border-border bg-bg px-3 text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "All papers"
					}), subjects.map((subject) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: subject.id,
						children: subject.name
					}, subject.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: rows.length < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Add at least two scores to see the line move."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MockChart, { rows })
			}),
			mocks.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex flex-col gap-2",
				children: mocks.slice().reverse().map((mock) => {
					const subject = subjects.find((item) => item.id === mock.subjectId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-fg",
							children: [
								subject?.short ?? "Paper",
								" · ",
								mock.score,
								"/",
								mock.total,
								" · ",
								formatDay(mock.date)
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => removeMock(mock.id),
							className: "min-h-11 px-2 text-muted",
							children: "Delete"
						})]
					}, mock.id);
				})
			})
		]
	});
}
function MockChart({ rows }) {
	const [lib, setLib] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("../_libs/recharts+[...].mjs").then((n) => n.t).then((mod) => {
			if (live) setLib(mod);
		});
		return () => {
			live = false;
		};
	}, []);
	if (!lib) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Chart is loading."
	});
	const { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } = lib;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-56 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
				data: rows,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						stroke: "var(--color-border)",
						strokeDasharray: "3 3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						stroke: "var(--color-muted)",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						domain: [0, 100],
						stroke: "var(--color-muted)",
						tick: {
							fill: "var(--color-muted)",
							fontSize: 12
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
						background: "var(--color-surface-2)",
						border: "1px solid var(--color-border)",
						borderRadius: 12,
						color: "var(--color-fg)"
					} }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: "pct",
						name: "Percent",
						stroke: "var(--color-eng)",
						strokeWidth: 2,
						dot: { r: 3 }
					})
				]
			})
		})
	});
}
function PrintSheet({ plan, subjects, stream }) {
	const weeks = (0, import_react.useMemo)(() => weekRows(plan), [plan]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "print-sheet px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "font-serif text-2xl",
				children: [
					"Desk 12 · ",
					streamLabel(stream),
					" · CBSE 2027"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Plan from ",
				formatFull(PLAN_START),
				" to ",
				subjects.at(-1) ? formatFull(subjects.at(-1).examDate) : "the last paper",
				". Eight hours on full days, lighter Saturdays, a past paper every Sunday, one revision day before each exam. Gap days belong to the next paper only."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: subjects.map((subject) => `${subject.short} ${formatDay(subject.examDate)}`).join(" · ") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
				"Mon",
				"Tue",
				"Wed",
				"Thu",
				"Fri",
				"Sat",
				"Sun"
			].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: label }, label)) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: weeks.map((week) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: week.days.map((day, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: day ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
					parseISODate(day.date).getDate(),
					" ",
					day.phase === "exam" ? "EXAM" : day.lighter ? "Light" : day.phase
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
				day.title
			] }) : null }, `${week.start}-${i}`)) }, week.start)) })] })
		]
	});
}
function weekRows(plan) {
	if (plan.length === 0) return [];
	const byDate = new Map(plan.map((day) => [day.date, day]));
	const first = plan[0].date;
	const dow = parseISODate(first).getDay();
	let cursor = addDays(first, dow === 0 ? -6 : 1 - dow);
	const last = plan[plan.length - 1].date;
	const weeks = [];
	while (cursor <= last) {
		const days = [];
		for (let i = 0; i < 7; i += 1) days.push(byDate.get(addDays(cursor, i)) ?? null);
		weeks.push({
			start: cursor,
			days
		});
		cursor = addDays(cursor, 7);
	}
	return weeks;
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeskApp, {});
}
//#endregion
export { Home as component };
