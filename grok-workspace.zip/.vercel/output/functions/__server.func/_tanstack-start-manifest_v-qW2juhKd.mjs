//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-qW2juhKd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B5sYPl2R.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B5sYPl2R.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CYbINPtC.js"]
	}
} });
//#endregion
export { tsrStartManifest };
